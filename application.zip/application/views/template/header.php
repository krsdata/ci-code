<?php 
	$segment= $this->uri->segment(2);
	$segment3= $this->uri->segment(3);
 	if($segment=='superadmin' || $segment=='') $dashboard='active'; else $dashboard=''; 
 	if($segment == 'users') $users = "active"; else $users = '';
 	if($segment=='slider' ) $slider='active'; else $slider=''; 
 	if($segment=='slider' ) $slider='active'; else $slider=''; 
 	if($segment=='pages' && ($segment3=='index' || $segment3=='add' || $segment3=='edit' )) $pages='active'; else  $pages='';
 	if($segment=='testimonials' || $segment=='addtestimonial' || $segment=='updatetestimonial'  )  $testimonial='active'; else  $testimonial='';
 	if($segment=='product_category' || $segment=='attributes' || $segment=='products' || $segment=='configure_terms')  $product='active'; else  $product='';
 	if($segment=='product_category' &&($segment3=='index' || $segment3=='add' || $segment3=='edit' )) $Categories='active'; else  $Categories='';
 	if( ($segment=='attributes' || $segment=='configure_terms') && ($segment3=='index' || $segment3=='add' || $segment3=='edit')) $Attribues='active'; else  $Attribues=''; 
 	if($segment=='products' && ($segment3=='index' || $segment3=='add_simple' || $segment3=='edit_simple' || $segment3=='add_variation' || $segment3=='edit_variation') ) $products='active'; else  $products='';
 	if($segment=='products' && $segment3=='best_sellers' ) $pbest_sellers='active'; else  $pbest_sellers='';
 	if($segment=='orders') $orders = 'active'; else $orders='';
 	if($segment=='orders' && $segment3=='index') $order = 'active'; else $order='';
 	if($segment=='orders' && $segment3=='best_sellers') $best_sellers = 'active'; else $best_sellers='';
 	if($segment=='orders' && $segment3=='bulk_orders') $bulk_orders = 'active'; else $bulk_orders='';
 	if($segment=='optionsettings') $options = 'active'; else $options='';
 	if($segment=='email_templates') $email_templates = 'active'; else $email_templates='';
 	if($segment=='supports') $supports = 'active'; else $supports='';
 	if($segment=='supports' && ($segment3=='index' || $segment3=='details') ) $support = 'active'; else $support='';
 	if($segment=='supports' && $segment3=='contacts') $contacts = 'active'; else $contacts='';
 	if($segment=='newsletters') $newsletters = 'active'; else $newsletters='';
 	if($segment=='corporate') $corporate = 'active'; else $corporate='';
 	if($segment=='corporate' && $segment3=='index' ) $corp_requests='active'; else  $corp_requests='';
 	if($segment=='corporate' && $segment3=='corporate_slider') $corporate_slider='active'; else  $corporate_slider='';
 	if($segment=='corporate' && ($segment3=='orders' || $segment3=='order_details')  ) $corp_orders='active'; else  $corp_orders='';
?>

<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en" class="no-js">
<!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
<meta charset="utf-8"/>
<title><?php if(isset($page_title)) { echo $page_title; }else{ echo "Admin panel"; } ?></title>
<!--  <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/favicon.ico" type="image/x-icon"> -->

<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta content="width=device-width, initial-scale=1" name="viewport"/>
<meta content="" name="description"/>
<meta content="" name="author"/>

<!-- BEGIN GLOBAL MANDATORY STYLES -->
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url() ?>assets/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url() ?>assets/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url() ?>assets/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url() ?>assets/global/plugins/uniform/css/uniform.default.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url() ?>assets/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css"/>

<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<!-- END GLOBAL MANDATORY STYLES bootstrap-datepicker.standalone.css-->
<!-- BEGIN PAGE LEVEL PLUGIN STYLES -->

<!-- END PAGE LEVEL PLUGIN STYLES -->
<!-- BEGIN PAGE STYLES -->
<link href="<?php echo base_url() ?>assets/admin/pages/css/tasks.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url() ?>assets/admin/pages/css/style.css" rel="stylesheet" type="text/css"/>
<!-- END PAGE STYLES -->
<!-- BEGIN THEME STYLES -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/accordian/css/vmenuModule.css" />

<link href="<?php echo base_url() ?>assets/global/css/components.css" id="style_components" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url() ?>assets/global/css/plugins.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url() ?>assets/admin/layout/css/layout.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url() ?>assets/admin/layout/css/themes/darkblue.css" rel="stylesheet" type="text/css" id="style_color"/>
<link href="<?php echo base_url() ?>assets/admin/layout/css/custom.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url() ?>assets/global/plugins/jquery-multi-select/css/multi-select.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url() ?>assets/admin/layout/css/jasny-bootstrap.min.css" rel="stylesheet">
<style type="text/css">
	.page-sidebar .page-sidebar-menu > li.active > a, .page-sidebar .page-sidebar-menu > li.active.open > a 
	{
    background: #1ABC9C;
	}
	.page-sidebar .page-sidebar-menu > li:hover > a, .page-sidebar .page-sidebar-menu > li.open > a {
	  background: #0E6352 !important;
	}
	.u-vmenu{
  white-space:nowrap;
	}
  #sortable { list-style-type: none; margin: 0; padding: 0; width: 60%; }
  #sortable li { margin: 0 3px 3px 3px; padding: 0.4em; padding-left: 1.5em; font-size: 1.4em; height: 18px; cursor: move; }
  #sortable li span { position: absolute; margin-left: -1.3em; }
</style>
<!-- END THEME STYLES -->
<!--<script type="text/javascript" src="<?php //echo base_url()?>assets/angular/angular.min.js"></script> -->
<!-- <script type="text/javascript" src="<?php //echo base_url()?>assets/angular/angular-slugify.js"></script> -->
<script src="<?php echo base_url() ?>assets/global/plugins/jquery.min.js" type="text/javascript"></script>
</head>
<body id="bid" ng-app="demoapp"  class="page-header-fixed page-quick-sidebar-over-content page-sidebar-closed-hide-logo page-container-bg-solid">
<!-- BEGIN HEADER -->
<div class="page-header navbar navbar-fixed-top">
	<!-- BEGIN HEADER INNER -->
	<div class="page-header-inner">
		<!-- BEGIN LOGO -->
		<div class="page-logo">
			<a href="<?php echo base_url(); ?>/superadmin" style="height:100%;"><h3>Cloud Steer</h3></a>
			<div class="menu-toggler sidebar-toggler hide">
			</div>
		</div>
		<!-- END LOGO -->
		<!-- BEGIN RESPONSIVE MENU TOGGLER -->
		<a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse">
		</a>
		<!-- END RESPONSIVE MENU TOGGLER -->
		<!-- BEGIN TOP NAVIGATION MENU -->
		<div class="top-menu">
			<ul class="nav navbar-nav pull-right">
				<li class="dropdown dropdown-user">
					<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
					<!-- <img alt="" class="img-circle" src="../../assets/admin/layout/img/avatar3_small.jpg"/> -->
					<?php 
 					$user_id = $this->session->userdata('admin_id');
					$loginuser=$this->Admin_model->getColumnDataWhere('user_master','first_name,last_name',array('id'=>$user_id),'',''); ?>
					<span class="username username-hide-on-mobile">
					<?php if(isset($loginuser)){ echo $loginuser[0]->first_name." ".$loginuser[0]->last_name;  } ?> </span>
					<i class="fa fa-angle-down"></i>
					</a>
					<ul class="dropdown-menu dropdown-menu-default">
						<li>
							<a href="<?php echo base_url(); ?>superadmin/profile">
							<i class="icon-user"></i> My Profile </a>
						</li>
						<li>
							<a href="<?php echo base_url(); ?>superadmin/change_password">
							<i class="icon-lock"></i>Change Password </a>
						</li>
						<li>
							<a href="<?php echo base_url('superadmin/logout'); ?>">
							<i class="icon-key"></i> Log Out </a>
						</li>
					</ul>
				</li>				
				<!-- END QUICK SIDEBAR TOGGLER -->
			</ul>
		</div>
		<!-- END TOP NAVIGATION MENU -->
	</div>
	<!-- END HEADER INNER -->
</div>
<!-- END HEADER -->
<div class="clearfix">
</div>
<!-- BEGIN CONTAINER -->
<div class="page-container">
	<!-- BEGIN SIDEBAR -->
	<div class="page-sidebar-wrapper">
		<!-- DOC: Set data-auto-scroll="false" to disable the sidebar from auto scrolling/focusing -->
		<!-- DOC: Change data-auto-speed="200" to adjust the sub menu slide up/down speed -->
		<div class="page-sidebar navbar-collapse collapse">
			<ul class="page-sidebar-menu " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200">
				<!-- DOC: To remove the sidebar toggler from the sidebar you just need to completely remove the below "sidebar-toggler-wrapper" LI element -->
				<li class="sidebar-toggler-wrapper">
					<!-- BEGIN SIDEBAR TOGGLER BUTTON -->
					<div class="sidebar-toggler">
					</div>
					<!-- END SIDEBAR TOGGLER BUTTON -->
				</li>
				<!-- DOC: To remove the search box from the sidebar you just need to completely remove the below "sidebar-search-wrapper" LI element -->
				<li class="sidebar-search-wrapper">
					<form class="sidebar-search " action="extra_search.html" method="POST">
						<a href="javascript:;" class="remove">
						<i class="icon-close"></i>
						</a>
					</form>
					<!-- END RESPONSIVE QUICK SEARCH FORM -->
				</li>
				<li class="<?php echo $dashboard; ?>">
					<a href="<?php echo base_url(); ?>superadmin/">
					<i class="icon-home"></i>
					<span class="title"> Dashboard</span>					
					</a>
				</li>
				<li class="<?php echo $pages; ?>" > 
					<a href="<?php echo base_url(); ?>pages/index"> 
					<i class="fa fa-book"></i>
					<span class="title"> eCoupon Manager</span> 
					</a>
				</li>
				<li class="<?php echo $users;  ?>">
					<a href="<?php echo base_url(); ?>users/">
					<i class="icon-user"></i>
					<span class="title"> SDFC User</span>
					</a>
					<ul class="sub-menu">
						<li class="<?php echo $users; ?>">
							<a href="<?php echo base_url(); ?>users/add">
							<i class="fa fa-send"></i>
							<span class="title">Retail/General User</span>
							</a>
						</li>
					</ul>	
				</li>			
				<li class="<?php echo $options; ?>">
					<a href="<?php echo base_url(); ?>optionsettings">
					<i class="fa fa-cogs"></i>
					<span class="title"> SDFC Configuration </span>
					</a>
				</li>
				<li class="<?php echo $email_templates; ?>">
					<a href="<?php echo base_url(); ?>email_templates">
					<i class="fa fa-envelope"></i>
					<span class="title">Redemption </span>
					</a>
				</li>
				<li class="<?php echo $supports;  ?>">
					<a href="<?php echo base_url(); ?>services/">
					<i class="fa fa-cart-plus"></i>
					<span class="title"> Service Offered</span>
					<span class="arrow"></span>
					</a>
				</li>
				<li class="<?php echo $newsletters; ?>">
					<a href="<?php echo base_url(); ?>newsletters">
					<i class="fa fa-clipboard"></i>
					<span class="title"> Region Manager </span>
					</a>
				</li>
				<li class="<?php echo $newsletters; ?>">
					<a href="<?php echo base_url(); ?>newsletters">
					<i class="fa fa-clipboard"></i>
					<span class="title"> User Type Manager </span>
					</a>
				</li>
				<li class="<?php echo $newsletters; ?>">
					<a href="<?php echo base_url(); ?>newsletters">
					<i class="fa fa-clipboard"></i>
					<span class="title"> Report </span>
					</a>
				</li>
				<li class="<?php echo $newsletters; ?>">
					<a href="<?php echo base_url(); ?>menu/add">
					<i class="fa fa-clipboard"></i>
					<span class="title"> Add Menu </span>
					</a>
				</li>
				<li class="<?php echo $users;  ?>">
					<a href="<?php echo base_url(); ?>role/">
					<i class="icon-user"></i>
					<span class="title"> Role Managment</span>
					</a>
					<ul class="sub-menu">
						<li class="<?php echo $users; ?>">
							<a href="<?php echo base_url(); ?>role/index">
							<i class="fa fa-send"></i>
							<span class="title">Role List</span>
							</a>
						</li>
						<li class="<?php echo $users; ?>">
							<a href="<?php echo base_url(); ?>role/add">
							<i class="fa fa-send"></i>
							<span class="title">Add Role</span>
							</a>
						</li>
					</ul>	
				</li>	
      </ul>
			<!-- END SIDEBAR MENU -->
		</div>
	</div>
	<!-- END SIDEBAR -->
<!-- <i class="fa fa-shopping-cart"></i> -->