<!-- BEGIN FOOTER -->
<div class="page-footer">
  <div class="page-footer-inner">
    2017 &copy; Cloud Steer
  </div>
  <div class="scroll-to-top">
    <i class="icon-arrow-up"></i>
  </div>

</div>
<!-- loader modal start -->
<div class="load-modal" id="load_modal">
  <img src="<?php echo base_url('assets/admin/layout/img/ajax-loader.gif'); ?>">
</div>
<!-- loader modal end --> 
<!-- END FOOTER -->
<!-- Price modal start -->
<div class="modal fade" id="Price_modal" role="dialog" tabindex="-1" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Please enter value equal or greater than one</h4>
      </div>
      <div class="modal-footer">
        <input type="button" data-dismiss="modal" class="btn modal_dismiss_btn" name="" value="OK">
      </div>
    </div>
  </div>
</div>
<!-- Price modal end --> 
<!-- Special Price modal start -->
<div class="modal fade" id="spl_Price_modal" role="dialog" tabindex="-1" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Please enter a numeric value</h4>
      </div>
      <div class="modal-footer">
        <input type="button" data-dismiss="modal" class="btn modal_dismiss_btn" name="" value="OK">
      </div>
    </div>
  </div>
</div>
<!-- Special Price modal end --> 
<!-- Common modal start -->
<div class="modal fade" id="Common_modal" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="modal_message"></h4>
      </div>
      <div class="modal-footer">
        <button type="button" data-dismiss="modal" class="btn">OK</button>
      </div>
    </div>
  </div>
</div>
<!-- Common modal end --> 
<!-- BEGIN JAVASCRIPTS(Load javascripts at bottom, this will reduce page load time) -->
<!-- BEGIN CORE PLUGINS -->
<!--[if lt IE 9]>
<script src="<?php echo base_url() ?>assets/global/plugins/respond.min.js"></script>
<script src="<?php echo base_url() ?>assets/global/plugins/excanvas.min.js"></script> 
<![endif]-->

<!-- IMPORTANT! Load jquery-ui.min.js before bootstrap.min.js to fix bootstrap tooltip conflict with jquery ui tooltip -->
<script type="text/javascript" src="<?php echo base_url() ?>assets/admin/js/jasny-bootstrap.min.js"></script>
<script src="<?php echo base_url() ?>assets/global/plugins/jquery-ui/jquery-ui.min.js" type="text/javascript"></script>
<script src="<?php echo base_url() ?>assets/global/plugins/bootstrap.min.js" type="text/javascript"></script>
<script src="<?php echo base_url() ?>assets/global/plugins/jquery-migrate.min.js" type="text/javascript"></script>
<script src="<?php echo base_url() ?>assets/global/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js" type="text/javascript"></script>
<script src="<?php echo base_url() ?>assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
<script src="<?php echo base_url() ?>assets/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
<script src="<?php echo base_url() ?>assets/global/plugins/jquery.cokie.min.js" type="text/javascript"></script>
<script src="<?php echo base_url() ?>assets/global/plugins/uniform/jquery.uniform.min.js" type="text/javascript"></script>
<script src="<?php echo base_url() ?>assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
<!-- END CORE PLUGINS -->
<!-- BEGIN PAGE LEVEL PLUGINS -->
<!-- IMPORTANT! fullcalendar depends on jquery-ui.min.js for drag & drop support -->
<!-- END PAGE LEVEL PLUGINS -->
<!-- BEGIN PAGE LEVEL SCRIPTS -->
<script src="<?php echo base_url() ?>assets/global/scripts/metronic.js" type="text/javascript"></script>
<script src="<?php echo base_url() ?>assets/admin/layout/scripts/layout.js" type="text/javascript"></script>


<script src="<?php echo base_url() ?>assets/global/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
<script src="<?php echo base_url() ?>assets/global/plugins/select2/select2.min.js" type="text/javascript"></script>

<script src="<?php echo base_url() ?>assets/global/plugins/jquery-multi-select/js/jquery.multi-select.js" type="text/javascript"></script>

<script src="<?php echo base_url() ?>assets/admin/js/jquery.fileuploadmulti.min.js" type="text/javascript"></script>
<script src="<?php echo base_url() ?>assets/bootbox.min.js" type="text/javascript"></script>
<script>
  $( function() {
    $( "#sortable" ).sortable();
    /*$( "#sortable_category" ).sortable();*/
    /*$( "#sortable" ).sortable({
        sort: function( ) {
         $('#all_variation_rows').html('');
         //alert("drag");
        }
    });*/
  } );
  </script>
<!-- <script src="<?php //echo base_url() ?>assets/admin/js/ui-bootstrap-tpls-0.10.0.min.js"></script> -->

<!-- <script src="//ajax.googleapis.com/ajax/libs/angularjs/1.5.0-beta.1/angular-sanitize.js"></script> -->

<!-- END PAGE LEVEL SCRIPTS -->
<script>

    $('#myTabs a').click(function (e) {
      e.preventDefault()
      $(this).tab('show')
    });

    var BASEURL= '<?php echo base_url(); ?>';
    //var ngApp=angular.module("demoapp", ["slugifier","ui.bootstrap"]);
 


    jQuery(document).ready(function() {    
      Layout.init(); // init layout
    });

    $(".alert").fadeOut(5000,"swing", function(){ $(this).remove();});
    /*$(".alert.alert-success").fadeOut(15000,"swing", function(){ $(this).remove();});
    $(".alert.alert-info").fadeOut(15000,"swing", function(){ $(this).remove();});
    $(".alert.alert-warning").fadeOut(15000,"swing", function(){ $(this).remove();});
    $(".alert.alert-danger").fadeOut(15000,"swing", function(){ $(this).remove();});*/

    $("#delete").click(function(e) {
      window.location=$("input[name='delurl']").val();
    });
    $(".delete_btn").click(function(event) 
    {
      $("input[name='delurl']").val($(this).attr('delurl'));
    });
</script>
<script type="text/javascript" src="<?php echo base_url() ?>assets/tinymce/tinymce.min.js"></script>
<script type="text/javascript">
  tinymce.init({
      //selector: "textarea",
      selector: ".tinymce_edittor",
      //height : 350,
      menubar: false,
      plugins: [
          "advlist autolink lists link image charmap print preview anchor media",
          "searchreplace visualblocks code fullscreen",
          "insertdatetime table contextmenu paste textcolor",        
      ],
      image_advtab: true,
      relative_urls: false,
      convert_urls: false,
      remove_script_host : false,
      toolbar: "insertfile undo redo | styleselect | bold italic forecolor backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image media | preview code ",

      file_browser_callback : elFinderBrowser
      /*function(field_name, url, type, win) 
      {
         var w = window.open('/elfinder/elfinder.html', null, 'width=900,height=440');
         w.tinymceFileField = field_name;
         w.tinymceFileWin = win;
      }*/
  });

  function elFinderBrowser (field_name, url, type, win) {
    tinymce.activeEditor.windowManager.open({
      file: '<?php echo base_url("elfinders");?>',// use an absolute path!
      title: 'File Manager',
      width: 900,  
      height: 450,
      resizable: 'yes'
    }, {
      setUrl: function (url) {
        document.getElementById(field_name).value = url;
      }
    });
    return false;
  }

  /*jQuery(document).ready(function($) {
    $('#elfinder_button').click(function(event) {
      elFinderBrowser ();
      event.preventDefault();
    });
  });*/
</script>

<script>
   function input_numeric(e)
   {
    if(e.value >= 0)
    {
      
    }
    else
    {
      $('#'+e.id+'').val(''); 
      $("#spl_Price_modal").modal("show");
    }
   }

  function input_grater_then_one(e)
  {
    if(e.value > 0 || e.value == "")
    {
      
    }
    else
    {
      $('#'+e.id+'').val(''); 
      $("#Price_modal").modal("show");
        //$('input[name='+e.name+']').val('');
        //alert("Please enter value equal or greater than one");
    }
  }
  
    $("#change_state").change(function(event) 
    {
        var state_id = this.value;
        $.post('<?php echo base_url("website/get_aus_cities")?>/'+state_id, function(data) 
        {
          $("#change_city").html(data);
        });
    });
  
    function max_text_count(e)
    {
      var maxlen = e.maxLength;
      var msg = "Maximum "+maxlen+" character are allowed.";
      var temp = e.value.length;
      var remaning = maxlen-temp;
      $("#text_count_msg").html(msg +"<span class='error'> "+remaning+" character are remaning.</span>");
    }
</script>
<script type="text/javascript">
      $(function() {
          $('.start_datepicker').datepicker({
            minDate: '<?php echo date("d-m-Y",time()+86400)?>',
            //defaultDate: "+1d",
            dateFormat: 'dd-mm-yy',
            changeMonth: true,
            changeYear: true,
            numberOfMonths: 1,
            onClose: function( selectedDate ) {
              $('.end_datepicker').datepicker( "option", "minDate", selectedDate );
            }
          });

          $('.end_datepicker').datepicker({
            minDate: '<?php echo date("d-m-Y",time()+86400)?>',
            startDate: 'd',
            //defaultDate: "+1d",
            dateFormat: 'dd-mm-yy',
            changeMonth: true,
            changeYear: true,
            numberOfMonths: 1,
            /*onClose: function( selectedDate ) {
              $('.start_datepicker').datepicker( "option", "maxDate", selectedDate );
            }*/
          });
        });

      $(document).ready(function() 
      {
        $('.datepicker').datepicker({
            //dateFormat: 'dd-mm-yyyy',
            changeMonth: true,
            changeYear: true,
            numberOfMonths: 1,
        });
      });

</script>
<script>
$(document).ready(function(){
    $('#multiSelect2').multiSelect({
    });
    $('a').tooltip(/*{
    animation: 'animated bounceInDown'
    }*/);  
  });
</script>
<script type="text/javascript" src="<?php echo base_url() ?>assets/accordian/js/vmenuModule.js"></script>
<script type="text/javascript">
  function PrintDiv(class_name) {
    var divToPrint = document.getElementsByClassName(class_name)[0];
    var popupWin = window.open('', '_blank', 'width=900,height=600,location=no');
    popupWin.document.open();
    popupWin.document.write('<html><head><link href="" rel="stylesheet" type="text/css"></head><body onload="window.print()">' + divToPrint.innerHTML + '</html>');
    popupWin.document.close();
  }
  // Javascript validation for Product images
  $(document).ready(function() {
    //Product Form Submit
    $("form[name=Product_form]").submit(function(e){
      $(".product_image").each(function(index, el) {
        var val=$(this).val();
        if (val == "") 
        {
          $("#modal_message").html("Please select an Image file.");
          $("#Common_modal").modal("show");
          e.preventDefault();
        }
      });
    });
    //  To add new input file field dynamically, on click of "Add More Files" button below function will be executed.
    $(".image_table").hide();
    $('#add_more_image_choose').click(function() 
    {
      var rowCount = $('#image_table_body tr').length;
      if (rowCount==0)
      {
        $(".image_table").show();
      }
      var img_count = ++rowCount;
      var input_html="<tr><td class='img_index'>"+ img_count +"</td><td><input type='file' name='product_img[]' class='product_image' id='image_id_unique_"+ img_count +"' ></td><td id='image_id_unique_"+ img_count +"_preview_td'></td><td><input type='radio' class='featured_radio' name='featured' value='"+ img_count +"'></td><td><a href='javascript:;' class='btn btn-danger btn-xs remove_this_image_only'>  <i class='fa fa-times'></i>  </a></td></tr>";
        $("#image_table_body").fadeIn('slow').append(input_html);
        $('.remove_this_image_only').click(function(event) {
          $(this).parent().parent("tr").remove();
          if ($('#image_table_body tr').length==0) 
          {
            $(".image_table").hide();
          }
          else
          {
            $(".img_index").each(function(index, el) {
              var set_val = index+1;
              $(".featured_radio")[index].val(set_val);
              $(this).html(set_val);
            });
          }
          event.preventDefault();
        });
        $(".product_image").change(function(event) {
          var id=$(this).prop('id');
          var val=$(this).val();
          $("#"+id+"_preview_td").html("");
          if (val != "") 
          {
            var file = document.getElementById(id).files[0];
            var src = URL.createObjectURL(file);
            var type = file.type.split('/').pop().toLowerCase();
            var size = file.size;
            if ((file )) {
              if (type != "jpeg" && type != "jpg" && type != "png" && type != "gif") 
              {
                $("#modal_message").html("Please select a valid Image file.");
                $("#Common_modal").modal("show");
                $("#"+id).parent().next(".image_preview").html("");
                document.getElementById(id).value = '';
                return false;
              }
              else if (size > 2048000 ) 
              {
                $("#modal_message").html("Size is greater than 2 MB");
                $("#Common_modal").modal("show");
                $("#"+id).parent().next(".image_preview").html("");
                document.getElementById(id).value = '';
                return false;
              }
              else
              {
                var img_id=id+"_preview_img";
                
                $("#"+id+"_preview_td").html("<img height='100px' src='"+src+"' id='"+img_id+"' />") ;
                $("#"+img_id).on('load', function() {
                  var image_height=$("#"+img_id)[0].naturalHeight;
                  var image_width=$("#"+img_id)[0].naturalWidth;
                  if (image_height < 350 || image_width < 350) 
                  {
                    document.getElementById(id).value = '';
                    $("#"+id+"_preview_td").html("");
                    $("#modal_message").html("Height and Width must not less than 350X350 px.");
                    $("#Common_modal").modal("show");
                    return false;
                  }
                  if (image_height > 900 || image_width > 1920) 
                  {
                    document.getElementById(id).value = '';
                    $("#"+id+"_preview_td").html("");
                    $("#modal_message").html("Height and Width must not exceed 1920X900 px.");
                    $("#Common_modal").modal("show");
                    return false;
                  }
                });
              }
            }
            return true;
          }
        });
    });
    
    if ($("input[name=corporate]").is(":checked")==true)
      $(".corporate_range").show();
    else
      $(".corporate_range").hide();
    $("input[name=corporate]").click(function(event) {
      if ($("input[name=corporate]").is(":checked")==true)
        $(".corporate_range").show();
      else
        $(".corporate_range").hide();
    });
  }); 
</script>
<!-- END JAVASCRIPTS -->
</body>
<!-- END BODY -->
</html>