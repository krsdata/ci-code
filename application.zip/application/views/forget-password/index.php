<!DOCTYPE html>
<html lang="en">
<!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
<meta charset="utf-8"/>
<title>Login</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<meta http-equiv="Content-type" content="text/html; charset=utf-8">
<meta content="" name="description"/>
<meta content="" name="author"/>
<!-- BEGIN GLOBAL MANDATORY STYLES -->
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css"/>
<link href="<?php echo BACKEND_THEME_URL ?>assets/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo BACKEND_THEME_URL ?>assets/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo BACKEND_THEME_URL ?>assets/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo BACKEND_THEME_URL ?>assets/global/plugins/uniform/css/uniform.default.css" rel="stylesheet" type="text/css"/>
<!-- END GLOBAL MANDATORY STYLES -->
<!-- BEGIN PAGE LEVEL STYLES -->
<link href="<?php echo BACKEND_THEME_URL ?>assets/admin/pages/css/login.css" rel="stylesheet" type="text/css"/>
<!-- END PAGE LEVEL SCRIPTS -->
<!-- BEGIN THEME STYLES -->
<link href="<?php echo BACKEND_THEME_URL ?>assets/admin/layout/css/custom.css" rel="stylesheet" type="text/css"/>
<!-- END THEME STYLES -->
<link rel="shortcut icon" href="favicon.ico"/>
</head>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="login" style="background-image: url('<?php echo base_url("assets/admin/layout/img/login_bg2.jpg"); ?>')">
<!-- BEGIN SIDEBAR TOGGLER BUTTON -->
     <div class="menu-toggler sidebar-toggler">
     </div>
     <!-- END SIDEBAR TOGGLER BUTTON -->
     <!-- BEGIN LOGO -->
     <div class="logo">
          <h1>Cloud Steer</h1>
     </div>
 <div class="content">
    <form class="login-form" action="" method="post">
               <h3 class="form-title">Sign In</h3>
               <div class="alert alert-info display-hide">
                    <button class="close" data-close="alert"></button>
                    <span>
                    <?php if(isset($labelmessage)) { echo $labelmessage;  } ?> </span>
               </div>
               <div class="form-group">
                    <!--ie8, ie9 does not support html5 placeholder, so we just show field title for that-->
                    <label class="control-label visible-ie8 visible-ie9">Email</label>
                    <input class="form-control form-control-solid placeholder-no-fix" type="text" autocomplete="off" name="username"/>
                    <?php echo form_error('username'); ?>
               </div>
               <div class="form-group">
                    <label class="control-label visible-ie8 visible-ie9">Verification Code:</label>
                    <div class='image'><?php echo $image; ?></div>
                    <a href='#' class ='refresh'><img id = 'ref_symbol' src ="<?php echo base_url(); ?>img/refresh.png"></a>
                    <br>
                    <br>
                    <input class="form-control form-control-solid placeholder-no-fix" type="text" autocomplete="off" name="captcha"/>
                    <?php echo form_error('captcha'); ?> 
               </div>
               <div class="form-actions">
                    <button type="submit" class="btn btn-success uppercase btn-login">Submit</button>
                    <button type="submit" class="btn btn-success uppercase btn-login">Cancel</button>
               </div>

          </form>
  </div>    
 <div class="copyright">
          <?php echo date("Y"); ?> © Cloud Steer. Admin panel.
     </div>
<!-- END JAVASCRIPTS -->
</body>
<!-- END BODY -->
</html>
<script type="text/javascript">

// Ajax post for refresh captcha image.
$(document).ready(function() {
$("a.refresh").click(function() {
jQuery.ajax({
type: "POST",
url: "<?php echo base_url(); ?>" + "index.php/captcha_controller/captcha_refresh",
success: function(res) {
if (res)
{
jQuery("div.image").html(res);
}
}
});
});
});
</script>
<script type="text/javascript">
$(function() {
	$("#user_email").focus();
	$("#frm_forgot_passwd").validationEngine();
	$( "#user_dob" ).datepicker({
		dateFormat: 'dd-mm-yy',
		changeYear: true,
		changeMonth:true,
		showOn: "button",
		buttonImage: "<?php echo $this->adminImagePath;?>calendar.png",
		buttonImageOnly: true,
		maxDate: new Date(),
		yearRange: '<?php echo date('Y', strtotime('-70 year'));?>:<?php echo date('Y');?>'
	});
	$('#frm_forgot_passwd input[type]').keydown(function(e){
		var evt = window.event || e;
		var code = (evt.which!=undefined) ? evt.which : evt.charCode || evt.keyCode;
		if(code==13){
			setTimeout(function(){
				if($("#frm_forgot_passwd").validationEngine('validate')){
					$('#frm_btn').click();
				};
			}, 0);
			if ($.browser.msie==true) {
				evt.returnValue=false;
			}else{
				evt.preventDefault();
			}
			return false;
		}
	});
	$("#reload_image_captcha").click(function(){
		$.ajax({
			"type"		:	"POST",
			"url"		:	"<?php echo $this->reloadCaptchaRequest;?>",
			"success"	:	function(data){
				if(data!=undefined){
					try{
						var _res = eval(data);
						if(_res.err!=undefined && _res.id!=undefined && _res.msg!=undefined){
							if(_res.err=='0'){
								$('#captcha_id').val(_res.id);
								$('#image_captcha_box').html(_res.msg);
							}else{
								alert(_res.msg);
							}
						}
					}catch(e){}
				}
			}
		});
		return false;	
	});
});
</script>