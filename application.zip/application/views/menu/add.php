<div class="page-content-wrapper">
	<div class="page-content">
		<div class="clearfix"></div>
			<div class="content">
  <form action="" name="add-menu-form" id="add-menu-form" method="post" >
    <div class="toolbar">
      <div class="tools">
        <button type="submit" name="frm_btn" value="Save"><span><span class="save" tabindex="14">Save</span></span></button>
        <button type="submit" name="frm_btn" value="Save & New"><span><span class="s_new" tabindex="15">Save &amp; New</span></span></button>
        <button type="submit" name="frm_btn" value="Save & Close"><span><span class="s_close" tabindex="16">Save &amp; Close</span></span></button>
        <button type="button" value="Cancel" onclick="window.location.href='<?php //echo getControllerLinks()->listMenuTarget;?>';" ><span><span class="cancel" tabindex="17">Cancel</span></span></button>
      </div>
      <h2 class="user-m">Menu Management</h2>
    </div>
    <div class="container">
      <?php if(!empty($this->messages) && is_array($this->messages) && count($this->messages)==2):?>
      <div style="text-align:center;">
        <?php if(0===strcasecmp($this->messages[0], "success")):?>
        <font color="#009900"><b><?php echo $this->messages[1];?></b></font>
        <?php elseif(0===strcasecmp($this->messages[0], "error")):?>
        <font color="#FF0000"><b><?php echo $this->messages[1];?></b></font>
        <?php endif;?>
      </div>
      <?php endif;?>
      <div class="full">
        <fieldset style="overflow:auto;">
          <legend>Add Menu</legend>
          <table width="96%" border="0" cellpadding="5" cellspacing="3">
            <tr>
              <td>Display Name: <span class="mandatory_field">*</span></td>
              <td><input type="text" name="display_name" id="display_name" value="" class="validate[required]" maxlength="50" tabindex="2"/></td>
            </tr>
            <tr>
              <td>Redirect URL:</td>
              <td><input type="text" name="redirect_url" id="redirect_url" maxlength="500" tabindex="3" /></td>
            </tr>
            <tr>
              <td width="15%">Parent Menu: <span class="mandatory_field">*</span></td>
              <td>
                <select name="menu_parent" id="menu_parent" tabindex="4">
                  <option value="0"> -- Root Level -- </option>
                  <?php foreach($this->parentMenu as $key => $val) { ?>
                  <option title="<?php echo $val->hierarchical_name; ?>" value="<?php echo $val->menu_id; ?>"><?php echo $val->hierarchical_name; ?></option>
                  <?php } ?>
                </select></td>
            </tr>
            <tr>
              <td>Display Visibility: <span class="mandatory_field">*</span></td>
              <td><table width="24%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="1%"><input name="display_menu" type="radio" value="Y" class="check" checked="checked" tabindex="7"/></td>
                    <td width="20%">Show</td>
                    <td width="1%"><input name="display_menu" type="radio" class="check" value="N"  tabindex="8"/></td>
                    <td width="20%">Hide</td>
                  </tr>
                </table></td>
            </tr>
            <tr>
              <td>Status: <span class="mandatory_field">*</span></td>
              <td><table width="24%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="1%"><input name="menu_status" type="radio" value="Y" class="check" checked="checked" tabindex="7"/></td>
                    <td width="20%">Enable</td>
                    <td width="1%"><input name="menu_status" type="radio" class="check" value="N"  tabindex="8"/></td>
                    <td width="20%">Disable</td>
                  </tr>
                </table></td>
            </tr>            
          </table>
        </fieldset>
      </div>
      <div class="buttons">
        <button type="submit" name="frm_btn" value="Save"><span class="save" tabindex="10"><span>Save</span></span></button>
        <button type="submit" name="frm_btn" value="Save & New"><span class="s_new" tabindex="11"><span>Save &amp; New</span></span></button>
        <button type="submit" name="frm_btn" value="Save & Close"><span class="send_a" tabindex="12"><span>Save & Close</span></span></button>
        <button type="button" value="cancel" onclick="window.location.href='<?php //echo $this->listMenuTarget;?>'"><span class="cancel" tabindex="13"><span>Cancel</span></span></button>
      </div>
    </div>
    <div class="clear"></div>
  </form>
</div>
	</div>
</div>