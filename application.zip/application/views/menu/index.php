<div class="page-content-wrapper">
	<div class="page-content">
		<div class="clearfix"></div>
<div class="content">
  <div class="toolbar">
    <div class="tools">
      <button onclick="window.location.href='<?php //echo $this->addMenuTarget;?>'"><span><span class="new"  tabindex="14">New</span></span></button>
      <button id="edit-btn" value="Edit"><span><span class="edit"  tabindex="15">Edit</span></span></button>
      <button id="property-btn" value="Property" onclick="window.location.href='<?php //echo $this->mapPropertyMenuTarget;?>';"><span><span class="edit"  tabindex="16" >Property Mapping</span></span></button>
      <button id="enable-btn" value="Enable"<?php //if(strcmp($this->roleType,'superadmin')!=0):?> disabled="disabled" class="disabled-btn"  <?php //endif; ?> ><span><span class="enable"  tabindex="17" >Enable</span></span></button>
      <button id="disable-btn" value="Disable"<?php// if(strcmp($this->roleType,'superadmin')!=0):?> disabled="disabled" class="disabled-btn"  <?php //endif; ?> ><span><span class="disable"  tabindex="18">Disable</span></span></button>
      <button id="delete-btn" value="Delete"><span><span class="cancel"  tabindex="19">Delete</span></span></button>
    </div>
    <h2 class="user-m">Menu Management</h2>
  </div>
  <div class="container">
    <?php if(!empty($this->messages) && is_array($this->messages) && count($this->messages)==2):?>
    <div style="text-align:center;">
      <?php if(0===strcasecmp($this->messages[0], "success")):?>
      <font color="#009900"><b><?php echo $this->messages[1];?></b></font>
      <?php elseif(0===strcasecmp($this->messages[0], "error")):?>
      <font color="#FF0000"><b><?php echo $this->messages[1];?></b></font>
      <?php endif;?>
    </div>
    <?php endif;?>
    <div class="full">
      <table width="100%" border="0" cellpadding="4" cellspacing="1" class="art-manager">
        <thead class="filter">
          <tr>
            <td colspan="11">
            	<form name="search_form" id="search_form" method="get" action="/menu/setparams" >
                <input type="hidden" name="items" id="items"  />
                <table align="right" cellpadding="2">
                  <tr>
                    <td>Filter:</td>
                    <td><input type="text" name="search_key" value="<?php //echo $this->inputParams->searchKey?>" tabindex="1"/></td>
                    <td><select name="classification" tabindex="2">
                        <option value="">- Menu Type -</option>
                        <option value="menu" <?php //if($this->inputParams->classification==='menu'){?> selected="selected" <?php //}?> >Menu</option>
                        <option value="module" <?php //if($this->inputParams->classification==='module'){?> selected="selected" <?php //}?>>Module</option>
                        <option value="submodule" <?php //if($this->inputParams->classification==='submodule'){?> selected="selected" <?php //}?>>Sub Module</option>
                      </select></td>
                    <td><select name="status" tabindex="3">
                        <option value="">- Status -</option>
                        <option value="Y" <?php //if($this->inputParams->status==='Y'){?> selected="selected" <?php// }?>>Enabled</option>
                        <option value="N" <?php //if($this->inputParams->status==='N'){?> selected="selected" <?php //}?>>Disabled</option>
                      </select></td>
                    <td>From Date:</td>
                    <td><input type="text" name="date_from" id="from-d" tabindex="4" value="<?php //echo (!empty($this->inputParams->dateFrom))? date('d-m-Y',$this->inputParams->dateFrom):"";?>" readonly="readonly" /></td>
                    <td>To Date:</td>
                    <td><input type="text" name="date_to" id="to-d" tabindex="5" value="<?php// echo (!empty($this->inputParams->dateTo))?  date('d-m-Y',$this->inputParams->dateTo):"";?>" readonly="readonly" /></td>
                    <td><input type="submit" tabindex="6" class="ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only" id="act_adv_srch" name="search" value="Search" /></td>
                    <td><input type="button" tabindex="7" class="ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only" value="Clear" onclick="window.location.href='<?php //echo $this->listMenuTarget;?>'" /></td>
                  </tr>
                </table>
              </form></td>
          </tr>
        </thead>
        <thead>
          <tr>
            <th width="1%"><input type="checkbox" id="select_all" value="0" tabindex="8"/></th>
            <th width="45%"><a href="<?php //echo $this->url(array('sort' => 'hierarchical_name','order' => $this->inputParams->order)); ?>" <?php //if($this->inputParams->sort=='hierarchical_name'):?> class="<?php// echo $this->inputParams->linkClass; ?>" <?php //endif; ?> >Hierarchical Name</a></th>
            <th width="25%"><a href="<?php //echo $this->url(array('sort' => 'redirect_url','order' => $this->inputParams->order)); ?>" <?php //if($this->inputParams->sort=='redirect_url'):?> class="<?php //echo $this->inputParams->linkClass; ?>" <?php// endif; ?> >Redirect URL</a></th>
            <th width="10%"><a href="<?php //echo $this->url(array('sort' => 'classification','order' => $this->inputParams->order)); ?>" <?php //if($this->inputParams->sort=='classification'):?> class="<?php //echo $this->inputParams->linkClass; ?>" <?php //endif; ?> >Menu Type</a></th>
            <th width="11%"><a href="<?php// echo $this->url(array('sort' => 'creation_date','order' => $this->inputParams->order)); ?>" <?php //if($this->inputParams->sort=='creation_date'):?> class="<?php //echo $this->inputParams->linkClass; ?>" <?php //endif; ?> >Creation Date</a></th>
            <th width="6%"><a href="<?php //echo $this->url(array('sort' => 'is_active','order' => $this->inputParams->order)); ?>" <?php //if($this->inputParams->sort=='is_active'):?> class="<?php //echo $this->inputParams->linkClass; ?>" <?php //endif; ?> >Status</a></th>
          </tr>
        </thead>
        <tbody>
        <form name="menu_select_form" method="post">
          <input type="hidden" name="action_type" id="action_type" />
          <?php //if($this->numOfRecord > 0):?>
          <?php //foreach($this->menuList as $key=>$menuRow):    ?>
          <tr>
            <td><input type="checkbox" class="menu_select" name="menu_select[]" value="<?php //echo $menuRow->menu_id?>" /></td>
            <td width="45%"><a href="/menu/edit/id/<?php //echo $menuRow->menu_id?>"><?php// echo $menuRow->hierarchical_name; ?></a></td>
            <td width="23%"><span ><?php //echo $menuRow->redirect_url; ?></span></td>
            <td width="10%"><?php //echo ucwords($menuRow->classification); ?></td>
            <td width="12%"><?php //echo date('d-m-Y H:i:s',$menuRow->creation_date); ?></td>
            <td width="10%"><?php //echo ($menuRow->is_active==='Y')? '<div class="enabled"></div>': '<div class="disabled"></div>'; ?></td>
          </tr>
          <?php //endforeach; ?>
          <?php //else:?>
          <tr>
            <td colspan="8" style="color:red; font-weight:bold; text-align: center !important;"><?php //echo $this->adminTranslator->_('No record found.');?></td>
          </tr>
          <?php //endif;?>
        </form>
        </tbody>
        
        <?php //if($this->numOfRecord > 0):?>
        <tfoot>
          <tr>
            <td colspan="10" align="center"><?php// echo $this->paginationControl($this->paginator, 'Sliding', 'common/pagination.php', array('itemsPerPage' => $this->itemsPerPage));?></td>
          </tr>
        </tfoot>
        <?php //endif;?>
      </table>
    </div>
    <div>&nbsp;</div>
    <div class="buttons">
      <button onclick="window.location.href='<?php //echo $this->addMenuTarget;?>'"><span class="new" tabindex="9"><span>New</span></span></button>
      <button id="edit-btn" value="Edit"><span class="edit" tabindex="10" ><span>Edit</span></span></button>
      <button id="property-btn" value="Property" onclick="window.location.href='<?php// echo $this->mapPropertyMenuTarget;?>';"><span class="edit" tabindex="11"><span>Property Mapping</span></span></button>
      <button id="enable-btn" value="Enable"<?php //if(strcmp($this->roleType,'superadmin')!=0):?> disabled="disabled" class="disabled-btn"  <?php //endif; ?> ><span class="publish" tabindex="12" ><span>Enable</span></span></button>
      <button id="disable-btn" value="Disable" <?php //if(strcmp($this->roleType,'superadmin')!=0):?> disabled="disabled" class="disabled-btn"  <?php //endif; ?> ><span class="unpublish" tabindex="13"><span>Disable</span></span></button>
      <button class="button" id="delete-btn" value="Delete" ><span class="cancel" tabindex="14"><span>Delete</span></span></button>
    </div>
  </div>
  <div class="clear"></div>
</div>
</div>
</div>
<script>
$(function() {
	$( "#accordion" ).accordion({
		collapsible: true,
		autoHeight: false
	});
	$('#dialog_link, #button, #menu a').hover(
				function() { $(this).addClass('ui-state-hover'); }, 
				function() { $(this).removeClass('ui-state-hover'); }
	);
	
	// Datepicker
	$( "#from-d, #to-d" ).datepicker({
		dateFormat: 'dd-mm-yy',
		changeYear: true,
		changeMonth:true,
		showOn: "both",
		buttonImage: "<?php echo $this->adminImagePath;?>calendar.png",
		buttonImageOnly: true,
		beforeShow: customRange	
	});

	$("#edit-btn, #delete-btn, #enable-btn, #disable-btn, #delete-btn").click(
		function()
		{
			var result=true;
			var action = this.value.toLowerCase();
			var chkLength= $(".menu_select:checked").length;
			
			if(chkLength==0){
				if(action=='edit'){
					var message = 'Please select a menu from list.';
				}else{
					var message = 'Please select at least one menu from list.';
				}
				alert(message);
				result=false;
			}else
			if(this.value=='Edit' && chkLength >= 2)
			{
				alert('You can edit only one menu at a time.');
				result=false;
			}
							
			if(result==true && this.value!='Edit'){
				result = confirm('Are you sure to  '+action+' '+ chkLength+' menu(s) ?');	
			}				
							
			if(result==true){													
				document.getElementById('action_type').value=this.value;				
				document.menu_select_form.submit();
			}									
	});

	/*select all check boxed*/
	$('#select_all').click(function () {				
		$(this).parents('table:eq(0)').find(':checkbox').attr('checked', this.checked);
	});		

	$('#items_per_page').change(function () {
		var itemValue=this.value;			
		document.search_form.items.value=itemValue;
		document.search_form.submit();							
	});

	$('[name="menu_select[]"]').click(function(){
		var _selOpt = $('#select_all');
		if(this.checked==false){
			_selOpt.attr("checked","");
		}
		if($('[name="menu_select[]"]:checked').length == $('[name="menu_select[]"]').length)
		{
			_selOpt.attr("checked","checked");
		}
	});

		
});


function customRange(input){
	var _obj = {};
	if(input.id == "from-d"){
		if($("#to-d").datepicker("getDate") != null){
			var _todate = $("#to-d").datepicker("getDate");
			_obj.maxDate = _todate;
		}
	}else if(input.id == "to-d"){
		if($("#from-d").datepicker("getDate") != null){
			var _fromdate = $("#from-d").datepicker("getDate");
			_obj.minDate = _fromdate;
		}
	}
	return _obj;
}
</script>