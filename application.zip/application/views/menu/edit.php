<!-- BEGIN CONTENT -->
<div class="page-content-wrapper">
	<div class="page-content">
		
		<div class="clearfix">
		</div>
		
		<div class="row">
			
			<div class="col-md-12 ">
				
				<?php  echo msg_alert_backend(); ?>
				<!-- BEGIN SAMPLE FORM PORTLET-->
				<div class="portlet box green ">
					<div class="portlet-title">
						<div class="caption">
							<i class="fa fa-edit"></i>
							Edit User
						</div>
						
					</div>
					<div class="portlet-body form">
              <form action="" method="post" class="signin_form form_wrpper" role="form">
							<div class="form-body">
								<div class="row">
									<div class="tab_content_wrp">
										<div class="container-fluid">
                    <section class="row margin_bottom_30">
                        <!-- Contact info tab-->
                        <div class="col-xs-12 col-sm-6 col-md-6">
                            <h4 class="yellow_head margin_bottom_20">Shipping Address</h4>
                            <div class="form-group">
                                <label for="">First Name<span class="error">*</span></label>
                                <input name="first_name" id="first_name" class="form-control" type="text"  value="<?php if(isset($update[0])) { echo $update[0]->first_name; }  else  echo set_value('first_name');?>"  placeholder="Enter First Name" >
                                <?php echo form_error('first_name'); ?>
                            </div>
                            <div class="form-group">
                                <label for="">Last Name<span class="error">*</span></label>
                                <input name="last_name" id="last_name" class="form-control" type="text" value="<?php if(isset($update[0])) { echo $update[0]->last_name; }  else  echo set_value('last_name');?>"  placeholder="Enter Last Name" >
                                <?php echo form_error('last_name'); ?>
                            </div>
                            <div class="form-group">
                                <label for="">Email<span class="error">*</span></label>
                                <input type="email" class="form-control b_input_change" id="email" name="email" value="<?php if(isset($update[0])) { echo $update[0]->email; }  else  echo set_value('email');?>" placeholder="Enter User Email">
                                <?php echo form_error('email'); ?>
                            </div>
                            <div class="form-group">
                                <label for="">Address<span class="error">*</span></label>
                                <input type="text" class="form-control b_input_change" id="address" name="address" value="<?php if(isset($update[0])) { echo $update[0]->address; }  else  echo set_value('address');?>" placeholder="Enter User Address">
                                <?php echo form_error('address'); ?>
                            </div>
                            <div class="form-group">
                                <label for="Country">Country<samll class="error">*</samll></label>
                                <?php $countries=get_all_countries();
                                if (!empty($countries))
                                { ?>
                                <select name="county" class="form-control countries" id="country1">
                                    <?php
                                    echo "<option value=''>Select Country</option>";
                                    foreach ($countries as $country)
                                    {
                                    $selected='';
                                    if ($country->country_name==$update[0]->county)
                                    {
                                        $selected='selected';
                                    }
                                    echo "<option value=".$country->id." ".$selected." >".$country->country_name."</option>";
                                    }
                                    ?>
                                </select>
                                <?php
                                } ?>
                                <?php echo form_error('country'); ?>
                            </div>
                            <div class="form-group">
                                <label for="state">State<samll class="error">*</samll></label>
                                <div id="state_div">
                                    <select name="state" class="form-control states" id="state1">
                                        <option value=''>Select State</option>
                                    </select>
                                </div>
                                <?php echo form_error('state'); ?>
                            </div>
                            <div class="form-group">
                                <label for="city">City<span class="error">*</span></label>
                                <input type="text" class="form-control" id="cityId" name="city" value="<?php if(!empty($update[0])) { echo $update[0]->city; }  else  echo set_value('city');?>"/>
                                <?php echo form_error('city'); ?>
                            </div>
                            <div class="form-group">
                                <label for="">Postal Code<span class="error">*</span></label>
                                <input type="text" class="form-control b_input_change" id="zip" name="zip" value="<?php if(isset($update[0])) { echo $update[0]->zip; }  else  echo set_value('zip');?>" placeholder="Enter Postal Code">
                                <?php echo form_error('zip'); ?>
                            </div>
                            <div class="form-group">
                                <label for="">Phone no.<span class="error">*</span></label>
                                <input type="text" class="form-control b_input_change" id="mobile" name="mobile" value="<?php if(isset($update[0])) { echo $update[0]->mobile; }  else  echo set_value('mobile');?>" placeholder="Enter Phone Number">
                                <?php echo form_error('mobile'); ?>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-6 col-md-6">
                            <h4 class="yellow_head margin_bottom_20">Billing Address</h4>
                            <div class="form-group">
                            <label for="s_firs_tname">First Name<span class="error">*</span></label>
                                <input type="text" class="form-control s_input_change" id="s_first_name" name="s_first_name" value="<?php if(!empty($update[0])) { echo $update[0]->s_first_name; }  else  echo set_value('s_first_name');?>" placeholder="Enter First Name" >
                                <?php echo form_error('s_first_name'); ?>
                            </div>
                            <div class="form-group">
                            <label  for="s_last_name">Last Name<span class="error">*</span></label>
                                <input type="type" class="form-control s_input_change" id="s_last_name" name="s_last_name" value="<?php if(!empty($update[0])) { echo $update[0]->s_last_name; }  else  echo set_value('s_last_name');?>" placeholder="Enter Last Name" >
                                <?php echo form_error('s_last_name'); ?>
                            </div>
                            <div class="form-group">
                            <label for="s_email">Email address<span class="error">*</span></label>

                                <input type="email" class="form-control s_input_change" id="s_email" name="s_email" value="<?php if(!empty($update[0])) { echo $update[0]->s_email; }  else  echo set_value('s_email');?>" placeholder="Enter Email">
                                <?php echo form_error('s_email'); ?>
                            </div>
                            <div class="form-group">
                                <label for="s_address">Address<span class="error">*</span></label>
                                <input type="text" class="form-control s_input_change" id="s_address" name="s_address" value="<?php if(!empty($update[0])) { echo $update[0]->s_address; }  else  echo set_value('s_address');?>" placeholder="Enter Shipping Address" >
                                <?php echo form_error('s_address'); ?>
                            </div>
                            <div class="form-group">
                          <label for="Country">Country<samll class="error">*</samll></label>
                          <?php $countries=get_all_countries();
                          if (!empty($countries))
                          { ?>
                          <select name="s_county" class="form-control countries" id="country2">
                              <?php
                              echo "<option value=''>Select Country</option>";
                              foreach ($countries as $country)
                              {
                                  $selected='';
                                  if ($country->country_name==$update[0]->s_county)
                                  {
                                    $selected='selected';
                                    $country_id=$country->id;
                                  }
                                  echo "<option value=".$country->id." ".$selected." >".$country->country_name."</option>";
                              }
                              ?>
                          </select>
                          <?php
                          } ?>
                          <?php echo form_error('s_country'); ?>
                          </div>
                            <div class="form-group">
                                <label for="state">State<samll class="error">*</samll></label>
                                <div id="state_div2">
                                    <select name="s_state" class="form-control s_states" id="state2">
                                    <option value=''>Select State</option>
                                </select>
                                </div>
                                <?php echo form_error('s_state'); ?>  
                            </div>
                            <div class="form-group">
                                <label for="city">City<span class="error">*</span></label>
                                <input type="text" class="form-control" id="cityId2" name="s_city" value="<?php if(!empty($update[0])) { echo $update[0]->s_city; }  else  echo set_value('s_city');?>"/>
                                <?php echo form_error('s_city'); ?>
                            </div>

                            <div class="form-group">
                                <label for="s_zip">Postal Code<span class="error">*</span></label>
                                <input type="text" class="form-control s_input_change" id="s_zip" name="s_zip" value="<?php if(!empty($update[0])) { echo $update[0]->s_zip; }  else  echo set_value('s_zip');?>" placeholder="Enter Postal Code">
                                <?php echo form_error('s_zip'); ?>
                            </div>

                            <div class="form-group">
                                <label for="s_mobile">Phone No.<span class="error">*</span></label>
                                <input type="text" class="form-control s_input_change" id="s_mobile" name="s_mobile" value="<?php if(!empty($update[0])) { echo $update[0]->s_mobile; }  else  echo set_value('s_mobile');?>" placeholder="Enter Phone Number">
                                <?php echo form_error('s_mobile'); ?>
                            </div>
                        </div>
                    </section>
											
										</div>
                  </div>
								</div>
							</div>
							<div class="form-actions">
								<div class="row">
									<div class="col-md-offset-3 col-md-9">
										<input class="btn green" type="submit" name="add_and_new" value="Save">
										<a href="<?php echo base_url(); ?>backend/users/index"> <button class="btn default" type="button">Cancel</button></a>
									</div>
								</div>
							</div>
              </form>
					</div>
				</div>
				<!-- END SAMPLE FORM PORTLET-->
			</div>
		</div>
	</div>
</div>
<!-- END CONTENT -->
<!-- BEGIN QUICK SIDEBAR -->

<!-- END QUICK SIDEBAR -->
</div>
<!-- END CONTAINER -->

<script>
    jQuery(document).ready(function($) 
    {
        var id=$("#country1").val();
        $.post('<?php echo base_url('backend/users/get_all_states');  ?>', {id:id,state:'<?php echo $update[0]->state; ?>'}, function(data, textStatus, xhr) {
            $("#state_div").html(data);
        });
        var id2=$("#country2").val();
        $.post('<?php echo base_url('backend/users/get_all_states2');  ?>', {id:id2,state:'<?php echo $update[0]->s_state; ?>'}, function(data, textStatus, xhr) {
            $("#state_div2").html(data);
        });
        $("#country1").change(function(event) 
        {
            var id=$(this).val();
            $.post('<?php echo base_url('backend/users/get_all_states');  ?>', {id:id,state:''}, function(data, textStatus, xhr) {
                $("#state_div").html(data);
            });
        });
        $("#country2").change(function(event) 
        {
            var id2=$(this).val();
            $.post('<?php echo base_url('backend/users/get_all_states2');  ?>', {id:id2,state:''}, function(data, textStatus, xhr) {
                $("#state_div2").html(data);
            });
        });	
    });
</script>