<!-- delete modal start -->
<div class="modal fade" id="myModal3" role="dialog">
	<div class="modal-dialog">
		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Are you sure want to delete this user?</h4>
			</div>
			<div class="modal-footer">
				<input type="hidden" name="delurl" value="">
				<button type="button" data-dismiss="modal" class="btn btn-danger" id="delete">Delete</button>
				<button type="button" data-dismiss="modal" class="btn">Cancel</button>
			</div>
		</div>
	</div>
</div>
<!-- delete modal end -->
<!-- BEGIN CONTENT -->
<div class="page-content-wrapper">
	<div class="page-content">
		<div class="clearfix">
		</div>
		<div class="row">
			<div class="col-md-12">
				<?php  echo msg_alert_backend(); ?>
				<!-- BEGIN SAMPLE TABLE PORTLET-->
				<div class="portlet box green">
					<div class="portlet-title">
						<div class="caption">
							<i class="fa fa-users fa-lg"></i> Users List <a href="<?php echo base_url('users/add') ?>" class="btn btn-xs yellow">Add New User <i class="icon-plus"></i> </a>
						</div>
					</div>
					<div class="portlet-body">
						<div class="table-responsive">
							<div class="col-md-12 well">
								<form action="<?php echo base_url('users/index'); ?>" method="get" accept-charset="utf-8">
									<!-- <div class="form-group"> -->
									<div class="col-md-4">
										<input type="text" value="<?php if(isset($_GET['search'])) echo $_GET['search']; ?>" class="form-control" name="search" placeholder="Enter first name or email to search user">
									</div>
									<!-- </div> -->
									<!-- <div class="form-group col-md-6"> -->
									<input type="submit" class="btn btn-primary" value="search">
									<a href="<?php echo base_url('users/index'); ?>" class="btn btn-danger"> Reset </a>
									<!-- </div> -->
								</form>
							</div>
							<table class="table table-bordered table-hover">
								<thead>
									<tr>
										<th width="5%">#</th>
										<th width="">Name</th>
										<th width="20%">Email</th>
										<th width="12%">Created </th>
										<th width="5%">Status</th>
										<th width="8%">Actions</th>
										<th width="15%">Corporate status</th>
									</tr>
								</thead>
								<tbody>
									<?php
									if (!empty($users)):
										$i = 0; foreach ($users as $row) { $i++;
									?>
									<tr>
										<td><?php echo $i . "."; ?></td>
										<td>
											<a href="<?php echo base_url( 'users/edit/' . $row->id )?>" class="btn btn-small"  rel="tooltip" data-placement="left" data-original-title=" Edit ">
												<?php if(!empty($row->first_name)) echo $row->first_name; if(!empty($row->last_name)) echo ' '.$row->last_name; ?>
											</a>
										</td>
										<td><?php if(!empty($row->email)) echo $row->email; ?></td>
										<td><?php echo date('Y-m-d', strtotime($row->created_at)); ?></td>
										<td>
											<?php if($row->status){ ?> <a data-toggle="tooltip" data-placement="left" title="Active" href="<?php echo base_url().'users/status/'.$row->id.'/'.$row->status.'/'.$offset; ?>"><span  class="btn btn-xs green"><i class="fa fa-check-circle "></i></span></a> <?php  }else{  ?>  <a data-toggle="tooltip" data-placement="left" title="InActive" href="<?php echo base_url().'users/status/'.$row->id.'/'.$row->status.'/'.$offset; ?>"><span  class="btn btn-xs red"><i class="fa fa-times-circle"></i></span></a>  <?php } ?>
										</td>
										<td>
											<a href="<?php echo base_url('users/edit/' . $row->id ) ?>" class="btn btn-success btn-xs" rel="tooltip" data-placement="left" data-original-title=" Edit "><i class="icon-pencil"></i></a>
											<a href="#" class="btn btn-danger btn-xs delete_btn" rel="tooltip" rel="tooltip" data-placement="bottom" data-original-title="Remove"  delurl="<?php echo base_url('users/delete/' . $row->id) ?>" id="delete_btn" data-toggle="modal" data-target="#myModal3" data-controls-modal="myModal3" data-backdrop="static" data-keyboard="false" >
											<i class="icon-trash "></i></a>
										</td>
										<td><?php if (check_for_corp_request($row->email)) {
											if($row->corp_user){ ?> <a data-toggle="tooltip" data-placement="left" title="Active" href="<?php echo base_url().'users/corp_user/'.$row->id.'/'.$row->corp_user.'/'.$offset; ?>"><span  class="btn btn-xs green"><i class="fa fa-check-circle "></i></span></a> <?php  }else{  ?>  <a data-toggle="tooltip" data-placement="left" title="InActive" href="<?php echo base_url().'users/corp_user/'.$row->id.'/'.$row->corp_user.'/'.$offset; ?>"><span  class="btn btn-xs red"><i class="fa fa-times-circle"></i></span></a>  <?php } } else { echo "N/A"; } ?></td>
									</tr>
									<?php } ?><?php else: ?>
									<tr>
										<th colspan="7">
											<center>No Users Found.</center>
										</th>
									</tr>
									<?php endif; ?>
								</tbody>
							</table>
							<div class="text-right">
								<?php if (!empty($pagination)) echo $pagination; ?>
							</div>
						</div>
					</div>
				</div>
				<!-- END SAMPLE TABLE PORTLET-->
			</div>
		</div>
	</div>
</div>
<!-- END CONTENT -->
</div>
<!-- END CONTAINER -->