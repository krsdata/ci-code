<!-- BEGIN CONTENT -->
<div class="page-content-wrapper">
	<div class="page-content">
		
		<div class="clearfix">
		</div>
		
		<div class="row">
			
			<div class="col-md-12 ">
				
				<?php  echo msg_alert_backend(); ?>
				<!-- BEGIN SAMPLE FORM PORTLET-->
				<div class="portlet box green ">
					<div class="portlet-title">
						<div class="caption">
							<i class="fa fa-edit"></i>
							Add User
						</div>
						
					</div>
					<div class="portlet-body form">
              <form action="" method="post" class="signin_form form_wrpper" role="form">
							<div class="form-body">
								<div class="row">
									<div class="tab_content_wrp">
										<div class="container-fluid">
	                    <section class="row margin_bottom_30">
	                        <!-- Contact info tab-->
	                        <div class="col-xs-12 col-sm-6 col-md-6">
	               
	                            <div class="form-group">
	                                <label for="">First Name<span class="error">*</span></label>
	                                <input name="first_name" id="first_name" class="form-control" type="text"  value="<?php echo set_value('first_name'); ?>"  placeholder="Enter First Name" >
	                                <?php echo form_error('first_name'); ?>
	                            </div>
	                            <div class="form-group">
	                                <label for="">Last Name<span class="error">*</span></label>
	                                <input name="last_name" id="last_name" class="form-control" type="text" value="<?php echo set_value('last_name'); ?>"  placeholder="Enter Last Name" >
	                                <?php echo form_error('last_name'); ?>
	                            </div>
	                            <div class="form-group">
	                                <label for="">Email<span class="error">*</span></label>
	                                <input type="email" class="form-control b_input_change" id="email" name="email" value="<?php echo set_value('email'); ?>" placeholder="Enter User Email">
	                                <?php echo form_error('email'); ?>
	                            </div>
	                            <div class="form-group">
	                                <label for="">Address<span class="error">*</span></label>
	                                <input type="text" class="form-control b_input_change" id="address" name="address" value="<?php echo set_value('address'); ?>" placeholder="Enter User Address">
	                                <?php echo form_error('address'); ?>
	                            </div>
	                            <div class="form-group">
	                                <label for="Country">Country<samll class="error">*</samll></label>
	                                <?php $countries=get_all_countries();
	                                if (!empty($countries))
	                                { ?>
		                                <select name="county" class="form-control countries" id="country1">
		                                    <?php
		                                    echo "<option value=''>Select Country</option>";
		                                    foreach ($countries as $country)
		                                    {
		                                    $selected='';
		                                    if (isset($_POST["county"]) && $country->country_name==country_name($_POST["county"]))
		                                    {

		                                      $selected='selected';
		                                    }
		                                    echo "<option value=".$country->id." ".$selected." >".$country->country_name."</option>";
		                                    }
		                                    ?>
		                                </select>
		                                <?php
	                                } ?>
	                                <?php echo form_error('county'); ?>
	                            </div>
	                            <div class="form-group">
	                                <label for="state">State<samll class="error">*</samll></label>
	                                <div id="state_div">
	                                    <select name="state" class="form-control states" id="state1">
	                                        <option value=''>Select State</option>
	                                    </select>
	                                </div>
	                                <?php
	                                $state_selected1='';
	                                if (isset($_POST["state"])) 
	                                {
	                                	$state_selected1=state_name($_POST["state"]);
	                                }
	                                ?>
	                                <?php echo form_error('state'); ?>
	                            </div>
	                            <div class="form-group">
	                                <label for="city">City<span class="error">*</span></label>
	                                <input type="text" class="form-control" id="cityId" name="city" value="<?php if(!empty($update[0])) { echo $update[0]->city; }  else  echo set_value('city');?>"/>
	                                <?php echo form_error('city'); ?>
	                            </div>
	                            <div class="form-group">
	                                <label for="">Postal Code<span class="error">*</span></label>
	                                <input type="text" class="form-control b_input_change" id="zip" name="zip" value="<?php if(isset($update[0])) { echo $update[0]->zip; }  else  echo set_value('zip');?>" placeholder="Enter Postal Code">
	                                <?php echo form_error('zip'); ?>
	                            </div>
	                            <div class="form-group">
	                                <label for="">Phone no.<span class="error">*</span></label>
	                                <input type="text" class="form-control b_input_change" id="mobile" name="mobile" value="<?php if(isset($update[0])) { echo $update[0]->mobile; }  else  echo set_value('mobile');?>" placeholder="Enter Phone Number">
	                                <?php echo form_error('mobile'); ?>
	                            </div>
	                            <div class="form-group">
																<label for="password">Password<samll class="error">*</samll></label>
																<input value="" name="password" type="password" placeholder="Enter User password" class="form-control">
																<?php echo form_error('password'); ?> 
															</div>
	                        </div>
	                    </section>
										</div>
                  </div>
								</div>
							</div>
							<div class="form-actions">
								<div class="row">
									<div class="col-md-offset-3 col-md-9">
										<input class="btn green" type="submit" name="add_and_new" value="Save">
										<a href="<?php echo base_url(); ?>users/index"> <button class="btn default" type="button">Cancel</button></a>
									</div>
								</div>
							</div>
              </form>
					</div>
				</div>
				<!-- END SAMPLE FORM PORTLET-->
			</div>
		</div>
	</div>
</div>
<!-- END CONTENT -->
<!-- BEGIN QUICK SIDEBAR -->

<!-- END QUICK SIDEBAR -->
</div>
<!-- END CONTAINER -->

<script>
    jQuery(document).ready(function($) 
    {
        var id=$("#country1").val();
        $.post('<?php echo base_url('backend/users/get_all_states');  ?>', {id:id,state:'<?php echo $state_selected1; ?>'}, function(data, textStatus, xhr) {
          $("#state_div").html(data);
        });
        var id2=$("#country2").val();
        $.post('<?php echo base_url('backend/users/get_all_states2');  ?>', {id:id2,state:'<?php echo $state_selected2; ?>'}, function(data, textStatus, xhr) {
            $("#state_div2").html(data);
        });
        $("#country1").change(function(event) 
        {
            var id=$(this).val();
            $.post('<?php echo base_url('backend/users/get_all_states');  ?>', {id:id,state:''}, function(data, textStatus, xhr) {
                $("#state_div").html(data);
            });
        });
        $("#country2").change(function(event) 
        {
            var id2=$(this).val();
            $.post('<?php echo base_url('backend/users/get_all_states2');  ?>', {id:id2,state:''}, function(data, textStatus, xhr) {
                $("#state_div2").html(data);
            });
        });	
    });
</script>