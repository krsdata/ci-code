<main id="content_page" class="content_page">
    <div class="container">
        <section class="breadcrumb_wrp">
            <div class="row breadcrumb_row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <ol class="breadcrumb">
                        <li class=""><a href="<?php echo base_url(); ?>">Home</a></li>
                        <li class=""><?php echo "Page Not Found"; ?></li>
                    </ol>
                </div>
            </div>    
        </section>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 success_col">
                <h4 class="big_title">404</h4>
                <div class="text-content">
                    <h3 class="tab_title">Lorem ipsum dolor sit amet, consectetur adipisicing elit,</h3>
                    <button type="button" class="btn_yellow">
                        Click Here
                    </button>
                </div>
            </div>
        </div>
    </div>
</main>