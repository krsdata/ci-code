<div class="page-content-wrapper">
	<div class="page-content">
		<div class="clearfix"></div>
<div class="content">
  <form action="" id="add_roll_form" name="add_roll_form" method="post">
    <div class="toolbar">
      <div class="tools">
        <button type="submit" name="frm_btn" value="Save"><span><span class="save" tabindex="8">Save</span></span></button>
        <button type="submit" name="frm_btn" value="Save & New"><span><span class="s_new" tabindex="9">Save &amp; New</span></span></button>
        <button type="submit" name="frm_btn" value="Save & Close"><span><span class="s_close" tabindex="10">Save &amp; Close</span></span></button>
        <button type="button" value="Cancel" onclick="window.location.href='<?php //echo $this->listRoleTarget;?>'" ><span><span class="cancel" tabindex="11">Cancel</span></span></button>
      </div>
      <h2 class="user-m">Role Management</h2>
    </div>
    <div class="container">
      <?php if(!empty($this->messages) && is_array($this->messages) && count($this->messages)==2):?>
      <div style="text-align:center;">
        <?php if(0===strcasecmp($this->messages[0], "success")):?>
        <font color="#009900"><b><?php echo $this->messages[1];?></b></font>
        <?php elseif(0===strcasecmp($this->messages[0], "error")):?>
        <font color="#FF0000"><b><?php echo $this->messages[1];?></b></font>
        <?php endif;?>
      </div>
      <?php endif;?>
      <div class="full">
        <fieldset>
          <legend>Add Role</legend>
          <table width="96%" border="0" cellpadding="5" cellspacing="3">       
            <tr>
              <td width="15%">Name:</td>
              <td><input type="text" id="role_name" name="role_name" class="validate[required]" maxlength="100" tabindex="2" /></td>
            </tr>
            <tr>
              <td>Type:</td>
              <td><table width="24%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                  	<?php if(!empty($this->superAdminExists)):?>
                  		<?php if($this->superAdminExists):?>
                  			<td width="1%"><input type="radio" class="check" name="role_type" value="superadmin" disabled="disabled" tabindex="3" /></td>
		                    <td width="50%">Super Admin</td>
		                    <td width="1%"><input type="radio" class="check" name="role_type" value="sdfc" checked="checked" tabindex="4" /></td>
		                    <td width="30%">SDFC</td>
		                    <td width="1%"><input type="radio" class="check" name="role_type" value="retailer" checked="checked" tabindex="4" /></td>
		                    <td width="30%">Retailer</td>
		                    <td width="1%"><input type="radio" class="check" name="role_type" value="general" checked="checked" tabindex="4" /></td>
		                    <td width="30%">General</td>
                    	<?php endif;?>
                    <?php else:?>
                    	<td width="1%"><input type="radio" class="check" name="role_type" value="superadmin" tabindex="3" /></td>
	                    <td width="50%">Super Admin</td>
	                    <td width="1%"><input type="radio" class="check" name="role_type" value="sdfc" checked="checked" tabindex="4" /></td>
	                    <td width="30%">SDFC</td>
	                    <td width="1%"><input type="radio" class="check" name="role_type" value="retailer" checked="checked" tabindex="4" /></td>
	                    <td width="30%">Retailer</td>
	                    <td width="1%"><input type="radio" class="check" name="role_type" value="general" checked="checked"  tabindex="4" /></td>
	                    <td width="30%">General</td>
                    <?php endif;?>
                  </tr>
                </table></td>
            </tr>
            <tr>
              <td>Status:</td>
              <td><table width="24%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="1%"><input id="status_enable" type="radio" class="check validate[required]" name="role_status" value="Y" checked="checked" tabindex="4" /></td>
                    <td width="30%">Enable</td>
                    <td width="1%"><input id="status_disable" type="radio" class="check validate[required]" name="role_status" value="N" /></td>
                    <td width="30%">Disable</td>
                  </tr>
                </table></td>
            </tr>
            <?php //if(!empty($this->propertyId)):?>
            <tr>
              <td valign="top">Permissions:</td>
              <td rowspan="2" valign="top"><div id="tabs">
                  <ul>
                    <li><a href="#tabs-1">Menu Permissions</a></li>
                  </ul>
                  <div id="tabs-1">
                    <?php 
							//if(0===strcmp($this->status,'success')):
							//	echo $this->tabData->menuList; 
							//else:
							//	echo $this->errorMessage;
						//	endif;						
						?>
                  </div>
                </div></td>
            </tr>
            <?php //endif;?>
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table>
        </fieldset>
      </div>
      <div class="buttons">
        <button type="submit" name="frm_btn" value="Save"><span class="save" tabindex="4"><span>Save</span></span></button>
        <button type="submit" name="frm_btn" value="Save & New"><span class="s_new" tabindex="5"><span>Save &amp; New</span></span></button>
        <button type="submit" name="frm_btn" value="Save & Close"><span class="send_a" tabindex="6"><span>Save &amp; Close</span></span></button>
        <button type="button" value="cancel" onclick="window.location.href='<?php //echo $this->listRoleTarget;?>'"><span class="cancel" tabindex="7"><span>Cancel</span></span></button>
      </div>
    </div>
    <div class="clear"></div>
  </form>
</div>
<script type="text/javascript">

$(document).ready(function(){
	$("#add_roll_form").validationEngine();			
	$("#browser,#browser2").treeview({
		animated:"fast",
		collapsed: true
	});
	$( "#tabs" ).tabs();

	$('.t-row').hide();	

	$("#select_property_code, #select_environment").change(function (){
		window.location.href = "<?php// echo $this->addRoleTarget;?>/prop_data/" + $("#select_property_code").val();
	});
		
	
	$('#sel_opt_all').click(function(){ 
		var _selOpt = $('input.chk_menu');
		var paramCkhBox = $('input.chk_perm');
		if(this.checked==true){
			_selOpt.attr("checked",true);
			$('.t-row').show();			
			paramCkhBox.attr("checked",true);
									
		}else{
			_selOpt.attr("checked",false);
			paramCkhBox.attr("checked",false);	
			$('.t-row').hide();										
		}
		toggleEmptyMesg();
	});	


	$('#sel_opt_all_cat').click(function(){ 
		var _selOpt = $('input.chk_category');
		if(this.checked==true){
			_selOpt.attr("checked",true);
		}else{
			_selOpt.attr("checked",false);
		}
	});	

	$('input.chk_menu').click(function(){		
		if(this.checked==true){
			$(this).parent('li').find('input[type="checkbox"]').each(function(){
				var _menuChkId = this.id;
				var _menuId = Number(_menuChkId.substring(10));					
				$(this).attr("checked", true);				
				$('#t-row_'+_menuId).show();
				$('#t-row_'+_menuId+' .chk_perm').attr("checked",true);
											
			});
		}else{
			$(this).parent('li').find('input[type="checkbox"]').each(function(){
				var _menuChkId = this.id;
				var _menuId = Number(_menuChkId.substring(10));					
				$(this).attr("checked", false);				
				$('#t-row_'+_menuId).hide();
				$('#t-row_'+_menuId+' .chk_perm').attr("checked",false);											
			});			
		}		
		isChecked();	
		toggleEmptyMesg();	
	}); 


	$('input.chk_category').click(function(){		
		if(this.checked==true){
			$(this).parent('li').find('input[type="checkbox"]').each(function(){
				$(this).attr("checked", true);				
			});
		}else{
			$(this).parent('li').find('input[type="checkbox"]').each(function(){
				$(this).attr("checked", false);				
			});			
		}		
	}); 


	
	
	$('input.chk_perm').click(function(){
		isChecked();
	});
	
	$('input[name="role_type"]').click(function(){
		var _selOpt = $('input.chk_menu');
		var paramCkhBox = $('input.chk_perm');
		if(this.value=='superadmin'){
			$('#sel_opt_all').attr("checked",true);
			$('#sel_opt_all_cat').attr("checked",true);
			$('input.chk_category').attr("checked",true);
			_selOpt.attr("checked",true);				
			paramCkhBox.attr("checked",true);
			$('.t-row').show();
			$('#no-item').hide();	
			$('#status_enable').attr("checked",true);
			$('#status_disable').attr("disabled",true);
			<?php /* vishwas need to change categories?>$("#tabs").attr("style","pointer-events: none;opacity:0.6;filter:alpha(opacity=60);");<?php */?>
		}else{
			$('#sel_opt_all').attr("checked",false);			
			_selOpt.attr("checked",false);
			$('#sel_opt_all_cat').attr("checked",false);
			$('input.chk_category').attr("checked",false);
			paramCkhBox.attr("checked",false);
			$('.t-row').hide();
			$('#no-item').show();		
			$('#status_disable').attr("disabled",false);
			$("#tabs").removeAttr("style");	
		}
	});

	$('button[name="frm_btn"]').click(function(){				
		var result=true;				
		var mLength= $(".chk_menu:checked").length;
		var pLength= $(".chk_perm:checked").length;			
		if(mLength==0 && pLength==0 ){
			alert('Please select atleast one permission.');
			result=false;
		}			
		return result;												
	});				
});

/*Function to check/uncheck Check All box*/
function isChecked(){	
	var _allMenuCount = $(".chk_menu").length;
	var _checkedMenuCount = $(".chk_menu:checked").length;
	var _allPermissionCount = $(".chk_perm").length;
	var _checkedPermissionCount = $(".chk_perm:checked").length;

	if( (_allMenuCount == _checkedMenuCount) && ( _allPermissionCount == _checkedPermissionCount ) ){
		$('#sel_opt_all').attr("checked", true);
	}else{
		$('#sel_opt_all').attr("checked", false);
	}	
}


function toggleEmptyMesg(){
	var _paramLength = $('.chk_perm:checked').length;
	if(_paramLength==0){
		$('#no-item').show();
	}else{
		$('#no-item').hide();
	}	
}

</script>
</div>
</div>
