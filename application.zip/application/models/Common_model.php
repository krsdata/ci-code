<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Common_model extends CI_Model
{
    public function insert($table_name = '', $data = '')
    {
        $query = $this->db->insert($table_name, $data);
        if ($query) return $this->db->insert_id();
        else return FALSE;
    }

    public function get_result($table_name = '', $id_array = '', $columns = array(), $order_by = array(),$limit='')

    {

        if (!empty($columns)):
            $all_columns = implode(",", $columns);
            $this->db->select($all_columns);
        endif;
        if (!empty($order_by)):
            $this->db->order_by($order_by[0], $order_by[1]);
        endif;
        if(!empty($id_array)):
            foreach ($id_array as $key => $value) {
                $this->db->where($key, $value);
            }
        endif;
        if (!empty($limit)):
            $this->db->limit($limit);
        endif;
        $query = $this->db->get($table_name);
        if ($query->num_rows() > 0) return $query->result();
        else return FALSE;
    }

    public function get_result_array($table_name = '', $id_array = '', $columns = array(), $order_by = array(),$limit='')

    {
        if (!empty($columns)):
            $all_columns = implode(",", $columns);
            $this->db->select($all_columns);
        endif;
        if (!empty($order_by)):
            $this->db->order_by($order_by[0], $order_by[1]);
        endif;
        if(!empty($id_array)):
            foreach ($id_array as $key => $value) {
                $this->db->where($key, $value);
            }
        endif;
        if (!empty($limit)):
            $this->db->limit($limit);
        endif;
        $query = $this->db->get($table_name);
        if ($query->num_rows() > 0) return $query->result_array();
        else return FALSE;
    }

    public function get_row($table_name = '', $id_array = '', $columns = array(), $order_by = array())
    {
        if (!empty($columns)):
            $all_columns = implode(",", $columns);
            $this->db->select($all_columns);
        endif;
        if(!empty($id_array)):
            foreach ($id_array as $key => $value) {
                $this->db->where($key, $value);
            }
        endif;
        if (!empty($order_by)):
            $this->db->order_by($order_by[0], $order_by[1]);
        endif;
        $query = $this->db->get($table_name);
        if($query->num_rows()>0) return $query->row();
        else return FALSE;
    }

    public function update($table_name = '', $data = '', $id_array = '')
    {
        if(!empty($id_array)):
            foreach($id_array as $key => $value){
                $this->db->where($key, $value);
            }
        endif;
        return $this->db->update($table_name, $data);
    }

    public function delete($table_name = '', $id_array = '')
    {
        return $this->db->delete($table_name, $id_array);
    }


    public function getColumnDataWhere($table,$column='',$where='',$orderby='',$ordertype='')
    {
        if($column !='')
        {
            $this->db->select($column);
        }
        else
        {
            $this->db->select('*');
        }   
        $this->db->from($table);
        if($where !='')
        {
            $this->db->where($where);
        }
        if($orderby !='')
        {
            $this->db->order_by($orderby,'ASC');
        }
        $query = $this->db->get();
        return $query->result();
    }

    public function page($slug=''){
        
        if(!empty($slug)){
            $query = $this->db->get_where('posts',array('post_slug'=>$slug,'post_type'=>'page', 'status'=>'1'));
            if($query->num_rows()>0)
                return $query->row();
            else
                return FALSE;
        }else{
            return FALSE;
        }
    } 

    public function get_in_array($table_name = '',$in_column='', $in_array = array(),$con_array='')
    {
        if(empty($in_array))
            return FALSE;

        /*if(!empty($in_array) && !empty($in_column)):*/
            $this->db->where_in($in_column, $in_array);
        /*endif;*/

        if(!empty($con_array)):
            foreach ($con_array as $key => $value) {
                $this->db->where($key, $value);
            }
        endif;
        $query = $this->db->get($table_name);
        if ($query->num_rows() > 0) return $query->result();
        else return FALSE;
    }

    public function get_result_pagination($tablename,$offset =0,$per_page ='',$condition=array(),$orderby='')
    {

        $this->db->from($tablename);
        if(!empty($condition))
        {
            foreach ($condition as $key => $value) 
            {
                $this->db->where($key, $value);
            }
        }
        
        if(!empty($orderby))
        {
           $this->db->order_by($orderby[0],$orderby[1]);
        }


        if($offset>=0 && $per_page>0)
        {
            $this->db->limit($per_page,$offset);
            $query = $this->db->get();
            if($query->num_rows()>0)
               return $query->result();
            else
                return FALSE;
        }
        else
        {
            return $this->db->count_all_results();
        }
    }
    
    public function buildCategory($parent='', $category='') 
    {
        $html = "";
        if (isset($category['parent_cats'][$parent])) {
            $html .= "<ul  id='sortable_category'>";
            foreach ($category['parent_cats'][$parent] as $cat_id) {
                if (!isset($category['parent_cats'][$cat_id])) {
                    $html .= "<li>  <a href='javascript:void(0)' class='categories' id='".$category['categories'][$cat_id]->id."'>". $category['categories'][$cat_id]->category_name . "</a></li> ";
                }
                if (isset($category['parent_cats'][$cat_id])) {
                    $html .= "<li>  <a href='javascript:void(0)' class='categories' id='".$category['categories'][$cat_id]->id."'>". $category['categories'][$cat_id]->category_name . "</a> ";
                    $html .= buildCategory($cat_id, $category);
                    $html .= "</li> ";
                }
            }
            $html .= "</ul> ";
        }
        return $html;
    }
    function buildCategory_add($parent='', $category='',$edit_category='') 
    {
        //$colors = array('red', 'green', 'blue', 'yellow', 'pink');
        //style='color:".$colors[$sort_order]."'
        $html = "";
        if (isset($category['parent_cats'][$parent])) 
        {
            foreach ($category['parent_cats'][$parent] as $cat_id) 
            {
                $selected='';
                if ($this->input->post('category_id')) 
                {
                    if (in_array($category['categories'][$cat_id]->id, $this->input->post('category_id'))) 
                    {
                        $selected='checked';
                    }
                }
                elseif (!empty($edit_category)) 
                {
                    if (in_array($category['categories'][$cat_id]->id,$edit_category)) 
                    {
                        $selected='checked';
                    }
                }
                $sort_order=$category['categories'][$cat_id]->sort_order;
                if (!isset($category['parent_cats'][$cat_id])) 
                {
                    $html .= "".$this->numbertodash($sort_order)."<input name='category_id[]' type='checkbox'  value='".$category['categories'][$cat_id]->id."'".$selected." />";
                    $html .= "<span>&nbsp;&nbsp;". $category['categories'][$cat_id]->category_name."</span><br>";
                }
                if (isset($category['parent_cats'][$cat_id])) 
                {
                    $html .= "".$this->numbertodash($sort_order)."<input  name='category_id[]' type='checkbox'  value='".$category['categories'][$cat_id]->id."'".$selected." />";
                    $html .= "<span>&nbsp;&nbsp;". $category['categories'][$cat_id]->category_name."</span><br>";
                    $html .= buildCategory_add($cat_id, $category,$edit_category);
                }
            }
        }
        return $html;
    }
    public function numbertodash($number='')
    {
        $hash='';
        for ($i=0; $i < $number; $i++) 
        { 
            $hash=$hash."&ensp;&ensp;&ensp;&ensp;";
        }
        return $hash;
    }

    

    public function get_cetegory_menu()
    {
        $this->db->from('product_category');
        $this->db->where('status','1');
        $this->db->where('fetured',null);
        $query = $this->db->get();
        if($query->num_rows()>0)
           return $query->result();
        else
            return FALSE;
    }

    public function get_all_countries()
    {
        $this->db->from('apps_countries');
        $query = $this->db->get();
        if($query->num_rows()>0)
           return $query->result();
        else
            return FALSE;
    }

    public function get_all_states()
    {
        $this->db->from('cities');
        $this->db->group_by('city_state');
        $query = $this->db->get();
        if($query->num_rows()>0)
           return $query->result();
        else
            return FALSE;
    }

    /*public function buildCategory_select($parent='', $category='') 
    {
        $html = "";
        if (isset($category['parent_cats'][$parent])) {
            $html .= "<ul class='selectdropdown' style='display:none'>";
            foreach ($category['parent_cats'][$parent] as $cat_id) {
                if (!isset($category['parent_cats'][$cat_id])) {
                    $html .= "<li><a href='".$category['categories'][$cat_id]->id."' class='categories'>". $category['categories'][$cat_id]->category_name . "</a></li> ";
                }
                if (isset($category['parent_cats'][$cat_id])) 
                {
                    $html .= "<li>  <a href='".$category['categories'][$cat_id]->id."' class='categories'>". $category['categories'][$cat_id]->category_name . "</a> ";
                    $html .= buildCategory_select($cat_id, $category);
                    $html .= "</li> ";
                }
            }
            $html .= "</ul> ";
        }
        return $html;
    }*/
}

