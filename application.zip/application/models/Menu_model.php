<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Menu_model extends CI_Model{

    public function __construct()
    {
        parent::__construct();
    }

    public function menu($offset = '', $per_page = '') 
    {
        $this->db->from('menu_master');
        //$this->db->where('role_id',1);
        if(isset($_GET['search']) && !empty($_GET['search']))
        {
            $this->db->group_start();
            $this->db->like('display_name',$_GET['search']);
            $this->db->group_end();
        }
        if ($offset >= 0 && $per_page > 0) {
            $this->db->limit($per_page, $offset);
            $this->db->order_by('menu_id', 'desc');
            $query = $this->db->get();
            if ($query->num_rows() > 0)
                return $query->result();
            else
               return FALSE;
        }
        else 
        {
            return $this->db->count_all_results();
        }
    }

    public function getParentInfo($menuId)
    {
        if(!empty($menuId)){
                $this->db->select('*');
                $this->db->from('menu_master');
                $this->db->where('menu_parent_id', $menuId);  // Also mention table name here
                $query = $this->db->get();   
                        if($query->num_rows()>0)
                            return $query->row();
                        else
                            return FALSE;
                    }else{
                        return FALSE;
                    }
    }
    public function getParentMenus($maxLevel){
        $className = get_class($this) . " --> " . __FUNCTION__;
        Site_Log::debug($className, $maxLevel);
        
        $result = NULL;
        $stmt = $this->_db->prepare('CALL ADMIN_MENU_GETPARENT_SP(:maxLevel)');
        $stmt->bindParam('maxLevel', $maxLevel);
        $stmt->execute();
        $result = $stmt->fetchAll();
        $stmt->closeCursor();
        
        Site_Log::debug($className, $this->_db->getProfiler()->getLastQueryProfile());
        return $result;
    }
}
