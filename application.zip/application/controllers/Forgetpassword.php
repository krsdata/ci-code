<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Forgetpassword extends CI_Controller {
     public function __construct()
     {
          parent::__construct();
          $this->load->helper('captcha');
          $this->load->library('image_lib');
     }
     public function index()
  {
     //print_r($_SESSION);
     //die;
          $data['labelmessage']="Enter Email and password.";
          $vals = array(
        'word'          => 'Random word',
        'img_path'      => './captcha/',
        'img_url'       => 'http://example.com/captcha/',
        'font_path'     => './path/to/fonts/texb.ttf',
        'img_width'     => '150',
        'img_height'    => 30,
        'expiration'    => 7200,
        'word_length'   => 8,
        'font_size'     => 16,
        'img_id'        => 'Imageid',
        'pool'          => '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',

        // White background and border, black text and red grid
        'colors'        => array(
                'background' => array(255, 255, 255),
                'border' => array(255, 255, 255),
                'text' => array(0, 0, 0),
                'grid' => array(255, 40, 40)
                  )
          );

          $cap = create_captcha($vals);
          echo $cap['image'];
          if($this->form_validation->run('login')==FALSE)
          {
               //echo "if"; die; 
               $this->form_validation->set_error_delimiters('<div class="form_error">','</div>');        
               $this->load->view('forget-password/index',$data);
          }
          else 
          {
               $email=$this->input->post('username');
               $password=$this->input->post('password');
               $where= array('email' =>$email,'password'=>md5($password),'role_id'=>0,'status'=>1);
               $res=$this->Admin_model->getColumnDataWhere('user_master','',$where,'','');
               if(count($res)>0)
               {
                    $this->session->set_flashdata('message', 'Welcome '.$res[0]->first_name." ".$res[0]->last_name);
                    $this->session->set_userdata(array('admin_name'=>$res[0]->user_name,'admin_id'=>$res[0]->id,'admin_role'=>0,'admin_logged_in'=>TRUE));
                    redirect('superadmin');
               } 
               else
               {
                    $data['labelmessage'] = "Invalid Email or Password Key";  
                    $this->load->view('login',$data);
               }
          }
     }
     // This function show values in view page and check captcha value.
public function form() {

else{
// Case comparing values.
if (strcasecmp($_SESSION['captchaWord'], $_POST['captcha']) == 0) {
echo "<script type='text/javascript'> alert('Your form successfully submitted'); </script>";
$this->captcha_setting();
} else {
echo "<script type='text/javascript'> alert('Try Again'); </script>";
$this->captcha_setting();
}
}
}
// This function generates CAPTCHA image and store in "image folder".
public function captcha_setting(){
$values = array(
'word' => '',
'word_length' => 8,
'img_path' => './images/',
'img_url' => base_url() .'images/',
'font_path' => base_url() . 'system/fonts/texb.ttf',
'img_width' => '150',
'img_height' => 50,
'expiration' => 3600
);
$data = create_captcha($values);
$_SESSION['captchaWord'] = $data['word'];

// image will store in "$data['image']" index and its send on view page
$this->load->view('captcha_view', $data);
}
// For new image on click refresh button.
public function captcha_refresh(){
$values = array(
'word' => '',
'word_length' => 8,
'img_path' => './images/',
'img_url' => base_url() .'images/',
'font_path' => base_url() . 'system/fonts/texb.ttf',
'img_width' => '150',
'img_height' => 50,
'expiration' => 3600
);
$data = create_captcha($values);
$_SESSION['captchaWord'] = $data['word'];
echo $data['image'];

}
}