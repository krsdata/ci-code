<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Menu extends CI_Controller {

	public function __construct()
 	{
    parent::__construct();
    if(superadmin_logged_in()==FALSE)
    {
      redirect('login'); 
    }
    $this->load->model('menu_model');
    $this->load->model('Common_model');
	}	
	public function index($offset = 0)
  {	
    $data['page_title'] = 'Dashboard :: Admin Panel';
    $per_page = 15;
    $data['offset']=$offset;
    $data['menu'] = $this->menu_model->menu($offset, $per_page);

    $config = backend_pagination();

    $config['base_url'] = base_url() . 'menu/index/';

    $config['total_rows'] = $this->menu_model->menu(0, 0);

    $config['per_page'] = $per_page;

    $config['uri_segment']  = 4;
    if(!empty($_SERVER['QUERY_STRING']))
    {
    $config['suffix']       = "?".$_SERVER['QUERY_STRING'];
    }

    $this->pagination->initialize($config);

    $data['pagination'] = $this->pagination->create_links();

    $data['template'] = "menu/index";
    $this->load->view('template/layout', $data);
	}
    

  public function add() 
  {  
      $data['page_title'] = 'Dashboard :: Admin Panel'; 
      $this->form_validation->set_error_delimiters('<div class="form_error">','</div>');

      if($this->form_validation->run('menu_add')==TRUE)
      { 

        $inset['display_name']    = $this->input->post('display_name');
        $inset['redirect_url']    = $this->input->post('redirect_url');
        $inset['menu_parent_id']    = $this->input->post('menu_parent');
        $inset['display_menu']    = $this->input->post('display_menu');
        $inset['is_active']    = $this->input->post('menu_status');
        $inset['created_date']    = date('Y-m-d h:i:s');
        $inset['modified_date']    = date('Y-m-d h:i:s');
        $inset['created_by'] =   $this->session->userdata('admin_id');
        $inset['modified_by'] =  $this->session->userdata('admin_id');
        $menuParent = $this->input->post('menu_parent');
        $displayName = $this->input->post('display_name');
        if($menuParent == 0){
              $menuLevel = 1;
              $hierarchicalName = $displayName;
            }else{
              $parentInfo = $this->Menu_model->getParentInfo($menuParent);
              $menuLevel = $parentInfo->menu_level + 1;
              $hierarchicalName = (!empty($parentInfo->hierarchical_name)) ? ($parentInfo->hierarchical_name .
             " --> " . $displayName) : ($displayName);
            }
        $inset['menu_level'] =  $menuLevel;
        $inset['hierarchical_name'] = $hierarchicalName;
        
          if($this->Common_model->insert('menu_master',$inset))
          {
              $this->session->set_flashdata('msg_success', 'Menu added successfully.'); 
          }
          else
          {

           $this->session->set_flashdata('msg_error', 'New add menu failed, Please try again.');

          }
          redirect('menu/index');
      } 
      // $maxLevel = $adminConfig->admin->menu->maxMenuLevel;
      // $parentMenu = $adminMenuTbl->getParentMenus($maxLevel - 1);
      $data['template']='menu/add'; 
      $this->load->view('template/layout', $data);
  } 



  public function edit($id=0,$offset=0)
  {  
    $data['offset'] = $offset;
    $data['page_title'] = 'Dashboard :: Admin Panel'; 
    $data['update']=$this->Admin_model->getColumnDataWhere('user_master','',array('id'=>$id,'role_id'=>1),'','');
    $this->form_validation->set_error_delimiters('<div class="form_error">','</div>');
    $this->session->set_userdata('edit_user_id',$id);
    if($this->form_validation->run('user_edit')==TRUE)
    {    
      $inset['first_name']      = $this->input->post('first_name');
      $inset['last_name']       = $this->input->post('last_name');
      $inset['email']           = $this->input->post('email');
      $inset['mobile']          = $this->input->post('mobile');
      $inset['address']         = $this->input->post('address');
      $inset['city']            = $this->input->post('city');
      $inset['state']           = state_name($this->input->post('state'));
      $inset['county']          = country_name($this->input->post('county'));
      $inset['zip']             = $this->input->post('zip');

      $inset['s_first_name']    = $this->input->post('s_first_name');
      $inset['s_last_name']     = $this->input->post('s_last_name');
      $inset['s_email']         = $this->input->post('s_email');
      $inset['s_mobile']        = $this->input->post('s_mobile');
      $inset['s_address']       = $this->input->post('s_address');
      $inset['s_city']          = $this->input->post('s_city');
      $inset['s_state']         = state_name($this->input->post('s_state'));
      $inset['s_county']        = country_name($this->input->post('s_county'));
      $inset['s_zip']           = $this->input->post('s_zip');

      $inset['modified_at']     = date('Y-m-d h:i:s');

      if($this->Common_model->update('user_master',$inset,array('id'=>$id,'user_role'=>1)))
      {
        $this->session->set_flashdata('msg_success', 'User updated successfully.');
      }
      else
      {
       $this->session->set_flashdata('msg_error', 'User update failed, Please try again.');
      }
      redirect('users/index/'.$offset);              

    }
    $data['template']='users/edit';     
    $this->load->view('template/layout',$data);
  } 



  public function delete($news_id = 0)
  {

      if (empty($news_id)) redirect('users');
      if ($this->Common_model->delete('user_master', array('id' => $news_id,'role_id'=>1))) {
          $this->session->set_flashdata('msg_success', 'User deleted successfully.');
      } else {
          $this->session->set_flashdata('msg_error', 'Delete failed, Please try again.');
      }

     redirect('users');
  }


  public function status($id="",$status="",$offset="")
  {
      if(empty($id)) redirect('users/');
      if($status==0){
          $cat_status=1;
      }

      if($status==1){
          $cat_status=0;
      }       

      $data = array('status'=>$cat_status);
      if($this->Common_model->update('user_master', $data ,array('id'=>$id)))
      {
         $this->session->set_flashdata('msg_success','User status has been updated successfully.');
      }
      else{
        $this->session->set_flashdata('msg_error', 'Status updated failed, Please try again.');

      }
      redirect('users/index/'.$offset);  
  }

  public function check_user_email($str)
  {
    $id = $this->session->userdata('edit_user_id');
    $check = $this->Common_model->get_row('user_master',array('id !='=>$id,'email'=>$str));
    if($check)
    { 
        $this->form_validation->set_message('check_user_email',"The email field must contain a unique value.");
        return FALSE;
    }
    else
    {
        return TRUE;
    }
  }
  public function get_all_states()
  {
    $html='';
    if ($_POST["id"]) 
    {
      $country_id=$_POST["id"];
      $states=$this->Common_model->get_result('state_master',array('country_id' =>$country_id,) );
      if (!empty($states)) 
      {
        $html=$html.'<select name="state" class="form-control states" id="state1"><option value="">Select State</option>';
        foreach ($states as $state) 
        {
          $selected="";
          if (strtoupper($_POST["state"])==strtoupper($state->state_name)) 
          {
            $selected="selected";
          }
          $html=$html."<option value=".$state->state_id." ".$selected." >".$state->state_name."</option>";
        }
        $html=$html."</select>";
      }
      else
      {
        $html=$html.'<input type="text" name="state"  class="form-control states" id="state1"  placeholder="Enter State Namessss" value="'.$_POST["state"].'" />';
      }
    }
    else
    {
      $html=$html.'<input type="text" name="state"  class="form-control states" id="state1" placeholder="Enter State Named" />';
    }
    echo $html;
  }
  public function get_all_states2()
  {
    $html='';
    if ($_POST["id"]) 
    {
      $country_id=$_POST["id"];
      $states=$this->Common_model->get_result('state_master',array('country_id' =>$country_id,) );
      if (!empty($states)) 
      {
        $html=$html.'<select name="s_state" class="form-control states2" id="state2"><option value="">Select State</option>';
        foreach ($states as $state) 
        {
          $selected="";
          if (strtoupper($_POST["state"])==strtoupper($state->state_name)) 
          {
            $selected="selected";
          }
          $html=$html."<option value=".$state->state_id." ".$selected." >".$state->state_name."</option>";
        }
        $html=$html."</select>";
      }
      else
      {
        $html=$html.'<input type="text" name="s_state"  class="form-control states2" id="state2" placeholder="Enter State Names" value="'.$_POST["state"].'" />';
      }
    }
    else
    {
      $html=$html.'<input type="text" name="s_state"  class="form-control states2" id="state2" placeholder="Enter State Name" />';
    }
    echo $html;
  }

  public function corp_user($id="",$status="",$offset="")
  {
    if(empty($id)) redirect('users/');
    if($status==0)
    {
      $cat_status=1;
    }

    if($status==1){
      $cat_status=0;
    }       
    $row_user = $this->Common_model->get_row("user_master", array('id'=>$id));
    if(empty($row_user)) redirect('users/');
    $data = array('corp_user'=>$cat_status);
    if($this->Common_model->update('user_master', $data ,array('id'=>$id)))
    {
      if ($cat_status) 
      {
        $email_template=$this->chapter247_email->get_email_template(12);
      }
      else
      {
        $email_template=$this->chapter247_email->get_email_template(13);
      }
      // mail to user
      $data['message'] = $email_template->template_body;
      $html = $this->load->view('templates/email/email',$data,true);
      $param=array(
          'template'  =>  array(
                        'temp'      =>  $html,
                        'var_name'  =>  array(
                            'user_name' => ucfirst($row_user->first_name)." ".$row_user->last_name, 
                            'login_url' => base_url("corporate"),
                            'site_name' => SITE_NAME, 
                                ),
                        ),      
          'email' =>  array(
                  'to'    =>   $row_user->email,
                  'from'    =>   NO_REPLY_EMAIL,
                  'from_name' =>   NO_REPLY_EMAIL_FROM_NAME,
                  'subject' =>   $email_template->template_subject,
                )
        );  
      $status=$this->chapter247_email->send_mail($param); 
      //mail to admin
      $data['message'] = $email_template->template_body_admin;
      $html = $this->load->view('templates/email/email',$data,true);
      $admin_param = array(
                'template'  =>  array(
                      'temp'      => $html,
                      'var_name'  => array(
                          'user_name'  => ucfirst($row_user->first_name)." ".$row_user->last_name,
                          'email'  => $row_user->email,
                          'site_name' => SITE_NAME,
                              ), 
                      ),            
                'email' =>  array(
                            'to'        => SUPERADMIN_EMAIL,
                            'from'      => NO_REPLY_EMAIL,
                            'from_name' => NO_REPLY_EMAIL_FROM_NAME,
                            'subject'   => $email_template->template_subject_admin,
                        )
              );
      $mail_status = $this->chapter247_email->send_mail($admin_param);
      $this->session->set_flashdata('msg_success','User status has been updated successfully.');
    }
    else{
      $this->session->set_flashdata('msg_error', 'Corporate user status updated failed, Please try again.');
    }
    redirect('users/index/?search='.$row_user->email);  
  }
}
