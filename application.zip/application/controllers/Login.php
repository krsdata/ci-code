<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
     public function __construct()
     {
          parent::__construct();
          // if(superadmin_logged_in()==TRUE)
          // {
          //      redirect('backend/superadmin'); 
          // }  
     }
     public function index()
  {
     //print_r($_SESSION);
     //die;
          $data['labelmessage']="Enter Email and password.";
          if($this->form_validation->run('login')==FALSE)
          {
               //echo "if"; die; 
               $this->form_validation->set_error_delimiters('<div class="form_error">','</div>');        
               $this->load->view('login',$data);
          }
          else 
          {
               $email=$this->input->post('username');
               $password=$this->input->post('password');
               $where= array('email' =>$email,'password'=>md5($password),'role_id'=>0,'status'=>1);
               $res=$this->Admin_model->getColumnDataWhere('user_master','',$where,'','');
               if(count($res)>0)
               {
                    $this->session->set_flashdata('message', 'Welcome '.$res[0]->first_name." ".$res[0]->last_name);
                    $this->session->set_userdata(array('admin_name'=>$res[0]->user_name,'admin_id'=>$res[0]->id,'admin_role'=>0,'admin_logged_in'=>TRUE));
                    redirect('superadmin');
               } 
               else
               {
                    $data['labelmessage'] = "Invalid Email or Password Key";  
                    $this->load->view('login',$data);
               }
          }
     }
}