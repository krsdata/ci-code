<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$config = array(
		'login'=>array(
						array(
								'field' => 'username',
								'label' => 'Email',
								'rules' =>  'trim|required|valid_email'
							),
						array(
								'field' => 'password',
								'label' => 'Password',
								'rules' => 'trim|required|max_length[50]'
							)	
					),

		'contact'=>array(
						array(
								'field' => 'name',
								'label' => 'Name',
								'rules' => 'trim|required|max_length[25]'
							),
						array(
								'field' => 'email',
								'label' => 'Email',
								'rules' =>  'trim|required|valid_email'
							),
						array(
								'field' => 'subject',
								'label' => 'Subject',
								'rules' => 'trim|required|max_length[50]'
							),
						array(
								'field' => 'message',
								'label' => 'Message',
								'rules' => 'trim|required|max_length[1000]'
							),			
					),

		'changePassword' => array(				
								   array(
											'field' => 'oldpassword',
											'label' => 'Old Password',
											'rules' => 'trim|required'
										),
									array(
											'field' => 'newpassword',
											'label' => 'New Password',
											'rules' =>  'trim|required|min_length[8]'
										 ),
									
									array(
											'field' => 'retypepassword',
											'label'  => 'Retype Password',
											'rules'  =>  'trim|required|min_length[8]|matches[newpassword]'
										  )
								), 
		'changePassword_using_link' => array(		
								array(
										'field' => 'newpassword',
										'label' => 'New Password',
										'rules' =>  'trim|required|min_length[8]'
									 ),
								
								array(
										'field' => 'retypepassword',
										'label'  => 'Retype Password',
										'rules'  =>  'trim|required|min_length[8]|matches[newpassword]'
									  )
							),  
							
		'product_category_add' => array(				
								  
									array(
											'field' => 'category_name',
											'label' => 'Name',
											'rules' =>  'trim|required|is_unique[product_category.category_name]'
										 ),
									array(
											'field' => 'cat_img',
											'label' => 'Category Image',
											'rules' => 'callback_features_image_check'
										 ),
								),

		
		'product_category_edit' => array(				
								  
									array(
											'field' => 'category_name',
											'label' => 'Name',
											'rules' =>  'trim|required|callback_check_updateproductcategory'
										 ),
									
									array(
											'field' => 'cat_img',
											'label' => 'Category Image',
											'rules' => 'callback_features_image_check'
										 ),
								),	
			 
			  'testimonial_add' => array(		
									   array(
											'field' => 'client_name',
											'label' => 'Name',
											'rules' =>  'trim|required'
										 ),
									  	array(
											'field' => 'feedback',
											'label' => 'Feedback',
											'rules' =>  'trim|required|max_length[900]'
										 ),

									  	/*array(
											'field' => 'features_image',
											'label' => 'Photo',
											'rules' =>  'trim|callback_testimonial_image_check_edit'
										 ), 

										array(
											'field' => 'features_image',
											'label' => 'Photo',
											'rules' =>  'trim|callback_testimonial_image_check_add'
										 ),*/
									
								),
			  'testimonial_edit' => array(				
								  
									
										array(
											'field' => 'client_name',
											'label' => 'Name',
											'rules' =>  'trim|required'
										 ),
									 	array(
											'field' => 'feedback',
											'label' => 'Feedback',
											'rules' =>  'trim|required|max_length[900]'
										 ),

										/*array(
											'field' => 'features_image',
											'label' => 'Photo',
											'rules' =>  'trim|callback_testimonial_image_check_edit'
										 ),*/ 
									
								),		 
			  'news_add' => array(				
								  
									
									    array(
											'field' => 'post_content',
											'label' => 'Content',
											'rules' =>  'trim|required'
										 ),

									   /*array(
											'field' => 'post_slug',
											'label' => 'Slug',
											'rules' =>  'trim|required|is_unique[posts.post_slug]|callback_slug_check'
										 ),*/

										array(
											'field' => 'post_title',
											'label' => 'Title',
											'rules' =>  'trim|required|is_unique[posts.post_title]'
										 ),

										array(
											'field' => 'features_image',
											'label' => 'Image',
											'rules' =>  'trim|callback_features_image_check_edit'
										 ),
									
								),

			  'news_edit' => array(	  
									
										array(
											'field' => 'post_content',
											'label' => 'Content',
											'rules' =>  'trim|required'
										 ),

									    /*array(
											'field' => 'post_slug',
											'label' => 'Slug',
											'rules' =>  'trim|required|callback_slug_check_edit'
										 ),*/

										array(
											'field' => 'post_title',
											'label' => 'Title',
											'rules' =>  'trim|required|callback_slug_check_edit'
										),

										array(
											'field' => 'features_image',
											'label' => 'Image',
											'rules' =>  'trim|callback_features_image_check_edit'
										 ),
									
								),
			  

			  'pages_add' => array(				
								  
									
										array(
											'field' => 'post_content',
											'label' => 'Content',
											'rules' =>  'trim|required'
										 ),

									    array(
											'field' => 'post_slug',
											'label' => 'Slug',
											'rules' =>  'trim|is_unique[posts.post_slug]'
										 ),

										array(
											'field' => 'post_title',
											'label' => 'Title',
											'rules' =>  'trim|required|is_unique[posts.post_title]'
										 ),
									
								),	
							
			  'page_edit' => array(												  									
										
										array(
											'field' => 'post_content',
											'label' => 'Content',
											'rules' =>  'trim|required'
										 ),
										array(
											'field' => 'blog_tagid',
											'label' => 'tag',
											'rules' => 'trim|required'
										 ),

									    array(
											'field' => 'post_slug',
											'label' => 'Slug',
											'rules' =>  'trim|required|callback_slug_check_edit'
										 ),

										array(
											'field' => 'post_title',
											'label' => 'Title',
											'rules' =>  'trim|required|callback_slug_check_edit'
										 ),
									
								),

			  'editmyprofile' => array(				
								  
									
									array(
											'field' => 'first_name',
											'label' => 'First Name',
											'rules' =>  'trim|required|alpha'
										 ),

									   array(
											'field' => 'last_name',
											'label' => 'Last Name',
											'rules' =>  'trim|required|alpha'
										 ),

									     array(
											'field' => 'email',
											'label' => 'Email',
											'rules' =>  'trim|required|valid_email'
										 ),

											
									
								),

			
			  'registration' => array(				
								  
									
									    array(
											'field' => 'fname',
											'label' => 'first name',
											'rules' => 'trim|required|alpha'
										 ),

									    array(
											'field' => 'lname',
											'label' => 'last name',
											'rules' => 'trim|required|alpha'
										 ),

									    array(
											'field' => 'email',
											'label' => 'email',
											'rules' =>  'trim|required|valid_email|is_unique[users.email]'
										 ),


										array(
											'field' => 'pwd',
											'label' => 'password',
											'rules' => 'trim|required|min_length[8]'
										 ),


										array(
											'field' => 'cpwd',
											'label' => 'confirm password',
											'rules' => 'trim|required|min_length[8]|matches[pwd]'
										 ),

										array(
											'field' => 'check_term',
											'label' => 'term & conditions',
											'rules' => 'trim|required'
										 ),
										
									
								),
				
				'user_password' => array(		

									    array(
											'field' => 'pwd',
											'label' => 'current password',
											'rules' => 'trim|required'
										 ),

									    array(
											'field' => 'npwd',
											'label' => 'new password',
											'rules' => 'trim|required|min_length[8]'
										 ),

									    array(
											'field' => 'cnpwd',
											'label' => 're-enter new password',
											'rules' => 'trim|required|min_length[8]|matches[npwd]'
										 ),	
								),

				'change_password' => array(												  

									    array(
											'field' => 'user_id',
											'label' => 'user id',
											'rules' => 'trim|required'
										 ),

									    array(
											'field' => 'npwd',
											'label' => 'new password',
											'rules' => 'trim|required|min_length[8]'
										 ),

									    array(
											'field' => 'cnpwd',
											'label' => 're-enter new password',
											'rules' => 'trim|required|min_length[8]|matches[npwd]'
										 ),	
								),

				'customer'=>array(
										array(
												'field' => 'email',
												'label' => 'Email',
												'rules' => 'trim|required|valid_email'
											),
										array(
												'field' => 'pwd',
												'label' => 'Password',
												'rules' => 'trim|required'
											)	
									),

				'forget_password'=>array(

										array(
												'field' => 'email',
												'label' => 'Email',
												'rules' => 'trim|required|valid_email'
											),
										array(
												'field' => 'captcha',
												'label' => 'Captcha',
												'rules' => 'trim|required'
											),
										),

			 'products_add_simple'=>array(
						array(
								'field' => 'title',
								'label' => 'title',
								'rules' => 'trim|required|is_unique[products.title]'
							),
					    array(
								'field' => 'description',
								'label' => 'description',
								'rules' => 'trim|required|max_length[2500]'
							),
							array(
								'field' => 'category_id[]',
								'label' => 'Category',
								'rules' => 'trim|callback_multiple_select'
							),
							array(
	                  'field' => 'corp_range',
	                  'label' => 'Corporate price range',
	                  'rules' => 'trim|callback_corp_range_validate'
	                ),
							array(
								'field' => 'price',
								'label' => 'Price',
								'rules' => 'trim|required'
							),
					    array(
								'field' => 'special_price',
								'label' => 'Special Price',
								'rules' => 'trim|callback_validate_special'
							),
							array(
								'field' => 'quantity',
								'label' => 'In Stock',
								'rules' => 'trim|required|is_natural'
							),
					    array(
								'field' => 'sku',
								'label' => 'SKU',
								'rules' => 'trim|required|callback_check_sku'
							),		
					),
			'products_add_variation'=>array(
												array(
													'field' => 'attribute_details',
													'label' => 'Variation',
													'rules' => 'callback_check_attribute'
												),
												array(
													'field' => 'title',
													'label' => 'title',
													'rules' => 'trim|required|is_unique[products.title]'
												),
												array(
													'field' => 'category_id[]',
													'label' => 'Category',
													'rules' => 'trim|callback_multiple_select'
												),
												array(
                          'field' => 'corp_range',
                          'label' => 'Corporate price range',
                          'rules' => 'trim|callback_corp_range_validate'
                        ),
												array(
													'field' => 'attributess[]',
													'label' => 'attributess',
													'rules' => 'required'
												),
										    array(
													'field' => 'description',
													'label' => 'Description',
													'rules' => 'trim|required|max_length[2500]'
												),
										    	array(
													'field' => 'price',
													'label' => 'Price',
													'rules' => 'trim|required'
												),	
												array(
													'field' => 'sku',
													'label' => 'SKU',
													'rules' => 'trim|required|callback_check_sku'
												),	
										),

			'attributes_add'=>array(
						
											array(
													'field' => 'attribute',
													'label' => 'Attribute',
													'rules' => 'trim|required|is_unique[product_attributes.attribute]'
												)
															
										),


			'attributes_edit'=>array(
						
											array(
													'field' => 'attribute',
													'label' => 'Attribute',
													'rules' => 'trim|required|callback_check_updateattributes'
												)
															
										),



			 	'configure_terms_add' =>array(
						
											array(
													'field' => 'name',
													'label' => 'Name',
													'rules' => 'trim|required|is_unique[product_configure_terms.name]'
												)
															
										),
			 	'configure_terms_edit'=>array(
						
											array(
													'field' => 'name',
													'label' => 'Name',
													'rules' => 'trim|required|callback_check_configure_terms'
												)
															
										),

						'slider_add' => array(		
							array(
									'field' => 'slider_title',
									'label' => 'Title',
									'rules' =>  'trim|required'
								 ),
							array(
								'field' => 'features_image',
								'label' => 'Image',
								'rules' =>  'trim|callback_features_image_check_add'
							),
							array(
								'field' => 'slider_url',
								'label' => 'Banner Callback url',
								'rules' =>  'trim|callback_check_url'
							),	
						),
           'slider_edit' => array(												  
							array(
											'field' => 'slider_title',
											'label' => ' Slider Title',
											'rules' =>  'trim|required'
										 ),
              array(
											'field' => 'features_image',
											'label' => 'Image',
											'rules' =>  'trim|callback_features_image_check_edit'
										 ),
              array(
								'field' => 'slider_url',
								'label' => 'Banner Callback url',
								'rules' =>  'trim|callback_check_url'
							),	
								),
       			'corporate_slider_add' => array(		
							array(
									'field' => 'slider_title',
									'label' => 'Title',
									'rules' =>  'trim|required'
								 ),
							array(
								'field' => 'features_image',
								'label' => 'Image',
								'rules' =>  'trim|callback_features_image_check_add'
							),
						),
						'corporate_slider_edit' => array(												  
							array(
											'field' => 'slider_title',
											'label' => ' Slider Title',
											'rules' =>  'trim|required'
										 ),
              array(
											'field' => 'features_image',
											'label' => 'Image',
											'rules' =>  'trim|callback_features_image_check_edit'
										 ),
								),
         'gallery_add' => array(				
								  
									
									array(
											'field' => 'gallery_title',
											'label' => 'Title',
											'rules' =>  'trim|required'
										 ),

                                    array(
										'field' => 'features_image',
										'label' => 'Image',
										'rules' =>  'trim|callback_features_image_check_add'
									 ),

								),

           'gallery_edit' => array(	
										array(
												'field' => 'gallery_title',
												'label' => 'Title',
												'rules' =>  'trim|required'
											 ),

	                                        array(
												'field' => 'features_image',
												'label' => 'Image',
												'rules' =>  'trim|callback_features_image_check_edit'
											 ),
									),


		    'update_detail_by_user'=>array(
									
									array(
										'field' => 'first_name',
										'label' => 'first name',
										'rules' => 'trim|required|alpha'
										),
									array(
										'field' => 'last_name',
										'label' => 'last name',
										'rules' => 'trim|required|alpha'
									),
									array(
										'field' => 'address',
										'label' => 'address',
										'rules' => 'trim|required'
									),
									array(
										'field' => 'city',
										'label' => 'city',
										'rules' => 'trim|required'
									),
									array(
										'field' => 'state',
										'label' => 'state',
										'rules' => 'trim|required'
									),
									array(
										'field' => 'zip',
										'label' => 'postal code',
										'rules' => 'trim|required|numeric'
									),
									/*array(
										'field' => 'county',
										'label' => 'county',
										'rules' => 'trim|required'
									),*/
									array(
										'field' => 'mobile',
										'label' => 'phone no.',
										'rules' => 'trim|required|numeric'
									),
									array(
										'field' => 's_first_name',
										'label' => 'first name',
										'rules' => 'trim|required|alpha'
									),
									array(
										'field' => 's_last_name',
										'label' => 'last name',
										'rules' => 'trim|required|alpha'
									),
									array(
										'field' => 's_email',
										'label' => 'email',
										'rules' => 'trim|required|valid_email'
									),
									array(
										'field' => 's_address',
										'label' => 'address',
										'rules' => 'trim|required'
									),
									array(
										'field' => 's_city',
										'label' => 'city',
										'rules' => 'trim|required'
									),
									array(
										'field' => 's_state',
										'label' => 'state',
										'rules' => 'trim|required'
									),
									array(
										'field' => 's_zip',
										'label' => 'postal code',
										'rules' => 'trim|required|numeric'
									),
									/*array(
										'field' => 's_county',
										'label' => 'county',
										'rules' => 'trim|required'
									),*/
									array(
										'field' => 's_mobile',
										'label' => 'phone no.',
										'rules' => 'trim|required|numeric'
									),
										
					),

			'contact_detail_at_buying'=> array(

									array(
										'field' => 'first_name',
										'label' => 'first name',
										'rules' => 'trim|required|alpha'
									),
									array(
										'field'	=> 'last_name',
										'label'	=> 'last name',
										'rules'	=> 'trim|required|alpha'
									),
									array(
										'field'	=> 'email',
										'label' => 'email',
										'rules'	=> 'trim|required|valid_email'
									),
									array(
										'field'	=> 'contact',
										'label' => 'phone number',
										'rules'	=> 'trim|required|numeric|min_length[10]'
									),	

					), 
			
			'update_detail_at_buying'=>array(
									
									array(
										'field' => 'first_name',
										'label' => 'first name',
										'rules' => 'trim|required|alpha'
										),
									array(
										'field' => 'last_name',
										'label' => 'last name',
										'rules' => 'trim|required|alpha'
									),
									array(
										'field' => 'address',
										'label' => 'address',
										'rules' => 'trim|required'
									),
									array(
										'field' => 'city',
										'label' => 'city',
										'rules' => 'trim|required'
									),
									array(
										'field' => 'state',
										'label' => 'state',
										'rules' => 'trim|required'
									),
									array(
										'field' => 'zip',
										'label' => 'postal code',
										'rules' => 'trim|required|numeric'
									),
									/*array(
										'field' => 'county',
										'label' => 'county',
										'rules' => 'trim|required'
									),*/
									array(
										'field' => 'mobile',
										'label' => 'phone no.',
										'rules' => 'trim|required|numeric'
									),
									array(
										'field' => 's_first_name',
										'label' => 'first name',
										'rules' => 'trim|required|alpha'
									),
									array(
										'field' => 's_last_name',
										'label' => 'last name',
										'rules' => 'trim|required|alpha'
									),
									array(
										'field' => 's_email',
										'label' => 'email',
										'rules' => 'trim|required|valid_email'
									),
									array(
										'field' => 's_address',
										'label' => 'address',
										'rules' => 'trim|required'
									),
									array(
										'field' => 's_city',
										'label' => 'city',
										'rules' => 'trim|required'
									),
									array(
										'field' => 's_state',
										'label' => 'state',
										'rules' => 'trim|required'
									),
									array(
										'field' => 's_zip',
										'label' => 'postal code',
										'rules' => 'trim|required|numeric'
									),
									/*array(
										'field' => 's_county',
										'label' => 'county',
										'rules' => 'trim|required'
									),*/
									array(
										'field' => 's_mobile',
										'label' => 'phone no.',
										'rules' => 'trim|required|numeric'
									),
										
					),

				'user_sign_up' => array(												  								
								    array(
										'field' => 'first_name',
										'label' => 'first Name',	
										'rules' => 'trim|required|alpha'
									 ),

								    array(
										'field' => 'last_name',
										'label' => 'last Name',
										'rules' => 'trim|required|alpha'
									 ),

								    array(
										'field' => 'email',
										'label' => 'email',
										'rules' => 'trim|required|valid_email|is_unique[users.email]'
									 ),

									array(
										'field' => 'password',
										'label' => 'password',
										'rules' => 'trim|required|min_length[8]'
									 ),
									array(
											'field' => 'c_password',
											'label' => 'confirm password',
											'rules' => 'trim|required|min_length[8]|matches[password]'
										 ),					
								
							),
				'user_add' => array(												  								
								    array(
										'field' => 'first_name',
										'label' => 'first Name',	
										'rules' => 'trim|required|alpha'
									 ),

								    array(
										'field' => 'last_name',
										'label' => 'last Name',
										'rules' => 'trim|required|alpha'
									 ),

								    array(
										'field' => 'email',
										'label' => 'email',
										'rules' => 'trim|required|valid_email|is_unique[users.email]'
									 ),

								    array(
										'field' => 'address',
										'label' => 'address',
										'rules' => 'trim|required'
									),

									array(
										'field' => 'password',
										'label' => 'password',
										'rules' => 'trim|required|min_length[8]'
									 ),

									array(
										'field' => 'city',
										'label' => 'city',
										'rules' => 'trim|required'
									),

									array(
										'field' => 'state',
										'label' => 'state',
										'rules' => 'trim|required'
									),

									array(
										'field' => 'county',
										'label' => 'Country',
										'rules' => 'trim|required'
									),

									array(
										'field' => 'zip',
										'label' => 'postal code',
										'rules' => 'trim|required|numeric'
									),
									array(
										'field' => 'mobile',
										'label' => 'phone number',
										'rules' => 'trim|required|numeric|min_length[10]'
									),

									array(
										'field' => 's_first_name',
										'label' => 'first Name',	
										'rules' => 'trim|required|alpha'
									 ),

								    array(
										'field' => 's_last_name',
										'label' => 'last Name',
										'rules' => 'trim|required|alpha'
									 ),

								    array(
										'field' => 's_email',
										'label' => 'email',
										'rules' => 'trim|required|valid_email'
									 ),

								    array(
										'field' => 's_address',
										'label' => 'address',
										'rules' => 'trim|required'
									),

									array(
										'field' => 's_city',
										'label' => 'city',
										'rules' => 'trim|required'
									),

									array(
										'field' => 's_county',
										'label' => 'Country',
										'rules' => 'trim|required'
									),
									
									array(
										'field' => 's_state',
										'label' => 'state',
										'rules' => 'trim|required'
									),

									array(
										'field' => 's_zip',
										'label' => 'postal code',
										'rules' => 'trim|required|numeric'
									),
									array(
										'field' => 's_mobile',
										'label' => 'phone number',
										'rules' => 'trim|required|numeric|min_length[10]'
									),								
								
							),
				'user_add_without_ship' => array(												  								
								    array(
										'field' => 'first_name',
										'label' => 'first Name',	
										'rules' => 'trim|required|alpha'
									 ),

								    array(
										'field' => 'last_name',
										'label' => 'last Name',
										'rules' => 'trim|required|alpha'
									 ),

								    array(
										'field' => 'email',
										'label' => 'email',
										'rules' => 'trim|required|valid_email|is_unique[users.email]'
									 ),

								    array(
										'field' => 'address',
										'label' => 'address',
										'rules' => 'trim|required'
									),

									array(
										'field' => 'password',
										'label' => 'password',
										'rules' => 'trim|required|min_length[8]'
									 ),

									array(
										'field' => 'city',
										'label' => 'city',
										'rules' => 'trim|required'
									),

									array(
										'field' => 'state',
										'label' => 'state',
										'rules' => 'trim|required'
									),

									array(
										'field' => 'zip',
										'label' => 'postal code',
										'rules' => 'trim|required|numeric'
									),
									array(
										'field' => 'mobile',
										'label' => 'phone number',
										'rules' => 'trim|required|numeric|min_length[10]'
									),							
								
							),
				'user_edit' => array(												  								
								    array(
										'field' => 'first_name',
										'label' => 'first Name',
										'rules' => 'trim|required|alpha|max_length[40]'
									 ),

								    array(
										'field' => 'last_name',
										'label' => 'last Name',
										'rules' => 'trim|required|alpha|max_length[40]'
									 ),

								    array(
										'field' => 'email',
										'label' => 'email',
										'rules' => 'trim|required|valid_email|callback_check_user_email'
									 ),

								    array(
										'field' => 'address',
										'label' => 'address',
										'rules' => 'trim|required|max_length[80]'
									),
								  array(
										'field' => 'county',
										'label' => 'Country',
										'rules' => 'trim|required'
									),
									array(
										'field' => 'state',
										'label' => 'state',
										'rules' => 'trim|required'
									),
									array(
										'field' => 'city',
										'label' => 'city',
										'rules' => 'trim|required'
									),
									array(
										'field' => 'zip',
										'label' => 'postal code',
										'rules' => 'trim|required|numeric'
									),
									array(
										'field' => 'mobile',
										'label' => 'phone number',
										'rules' => 'trim|required|numeric|min_length[10]|max_length[15]'
									),

									array(
										'field' => 's_first_name',
										'label' => 'first Name',
										'rules' => 'trim|required|alpha'
									 ),

								    array(
										'field' => 's_last_name',
										'label' => 'last Name',
										'rules' => 'trim|required|alpha'
									 ),

								    array(
										'field' => 's_email',
										'label' => 'email',
										'rules' => 'trim|required|valid_email'
									 ),

								    array(
										'field' => 's_address',
										'label' => 'address',
										'rules' => 'trim|required'
									),

								  array(
										'field' => 's_county',
										'label' => 'Country',
										'rules' => 'trim|required'
									),
									array(
										'field' => 's_state',
										'label' => 'state',
										'rules' => 'trim|required'
									),
									array(
										'field' => 's_city',
										'label' => 'city',
										'rules' => 'trim|required'
									),

									array(
										'field' => 's_zip',
										'label' => 'postal code',
										'rules' => 'trim|required|numeric'
									),
									array(
										'field' => 's_mobile',
										'label' => 'phone number',
										'rules' => 'trim|required|numeric|min_length[10]'
									),								
								
							),
			'emailtemplets_add' => array(				
									  
										array(
												'field' => 'template_name',
												'label' => 'Template Name',
												'rules' =>  'trim|required'
											 ),

										array(
												'field' => 'template_subject',
												'label' => 'Template Subject',
												'rules' =>  'trim|required'
											 ),
										array(
												'field' => 'template_body',
												'label' => 'Template Body',
												'rules' =>  'trim|required'
											 ),
									),		
			'bulk_order'=> array(

									array(
										'field' => 'name',
										'label' => 'Full Name',
										'rules' => 'trim|required|max_length[40]'
									),
									array(
										'field'	=> 'email',
										'label' => 'Email',
										'rules'	=> 'trim|required|valid_email'
									),
									array(
										'field'	=> 'phone',
										'label'	=> 'phone number',
										'rules'	=> 'trim|required|numeric|min_length[10]'
									),
									array(
										'field'	=> 'country',
										'label'	=> 'Country',
										'rules'	=> 'trim|required'
									),
									array(
										'field'	=> 'message',
										'label' => 'Message',
										'rules'	=> 'trim|required|max_length[4000]'
									),	

					),	
			'corp_sign_up' => array(												  								
								    array(
										'field' => 'f_name',
										'label' => 'First name',	
										'rules' => 'trim|required|alpha|max_length[50]'
									 ),
								    array(
										'field' => 'l_name',
										'label' => 'Last name',	
										'rules' => 'trim|required|alpha|max_length[50]'
									 ),

								    array(
										'field' => 'email',
										'label' => 'email',
										'rules' => 'trim|required|valid_email|is_unique[corporate_requests.email]'
									 ),

									array(
										'field' => 'mobile',
										'label' => 'phone number',
										'rules' => 'trim|required|numeric|min_length[10]|max_length[15]'
									 ),
									array(
											'field' => 'company',
											'label' => 'company name',
											'rules' => 'trim|required'
										 ),		
								 array(
									'field' => 'message',
									'label' => 'Message',
									'rules' => 'trim|required|min_length[10]|max_length[400]'
								 ),					
								
							),	
			'support' => array(     
                    array(
                    'field' => 'first_name',
                    'label' => 'First Name',
                    'rules' => 'trim|required'
                   ),
                    array(
                    'field' => 'last_name',
                    'label' => 'Last Name',
                    'rules' => 'trim|required'
                   ),
                    array(
                    'field' => 'email',
                    'label' => 'email',
                    'rules' => 'trim|required|valid_email'
                   ),
                    array(
                    'field' => 'mobile',
                    'label' => 'Contact Number',  
                    'rules' => 'trim|required|min_length[10]|max_length[10]'
                   ),

                  array(
                    'field' => 'subject',
                    'label' => 'Subject',
                    'rules' => 'trim|required'
                   ),
                  array(
                      'field' => 'comments',
                      'label' => 'Message',
                      'rules' => 'trim|required|min_length[10]|max_length[1000]'
                     ),                 
              ),
			'role_add' => array(  
                    array(
                    'field' => 'role_name',
                    'label' => 'Role Name',  
                    'rules' => 'trim|required'
                   ),                 
              ),
			  'menu_add' => array(  
			                array(
			                'field' => 'display_name',
			                'label' => 'Display Name',  
			                'rules' => 'trim|required'
			               ),

			              array(
			                'field' => 'display_menu',
			                'label' => 'Display Menu',
			                'rules' => 'trim|required'
			               ),                    
			          ),	
			'comment' => array(			
									array(
											'field' => 'comments',
											'label' => 'Message',
											'rules' => 'trim|required|max_length[1000]'
										 ),									
							),	
	)
?>
